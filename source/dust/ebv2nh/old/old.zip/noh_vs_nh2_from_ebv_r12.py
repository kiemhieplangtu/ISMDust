import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp

from restore             import restore

## Read NHI from 94src #
 #
 # params string fname Filename
 # return dict info of N(HI)
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_nhi_94src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_sponge_prior.txt'):
	cols = ['indx', 'src', 'l', 'b', 'nhi', 'nhi_er', 'thin', 'thin_er', 'cnm', 'cnm_er', 'wnm', 'wnm_er']
	fmt  = ['i',     's',   'f','f',  'f',   'f',     'f',     'f',        'f',   'f',      'f',   'f'   ]
	data = restore(fname, 2, cols, fmt)
	return data.read()

## Read info of 26 no-CO sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict infocd 
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_info_no_co(fname = '../../co12/result/26src_no_co_with_sponge.dat'):
	cols = ['idx','src','l','b','ra_icrs','de_icrs','ra_j','de_j', 'oh', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f','f', 'f',    'f',       's',    's',    'i', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Read info of 23 LOW NHI sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict info
 # 
 # version 12/2016
 # Author Van Hiep ##
def read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt'):
	cols = ['idx','src','l', 'b', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er', 'oh']
	fmt  = ['i',  's',  'f', 'f', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    , 'i']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_noh(fname = '../../oh/result/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret

## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 # params dict  noh      Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def nh_from_ebv(ebv_map, info, noh):
	## sources
	src   = info['src']
	nhi   = info['nhi']
	nhier = info['nhi_er']

	ohsc  = []
	for sc in noh:
		if(sc in src):
			ohsc.append(sc)

	# Define constants #
	deg2rad = np.pi/180.

	# Define the width of area #
	beam   = 5.            # Beam = 36'
	dbeam  = beam/120.0     # Beam = 36' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(ebv_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# cf,cf_er = [5.8e21, 0.0]
	# cf,cf_er = [68.83e20, 2.74e20]

	cf,cf_er   = [79.15e20, 5.46e20]   ## From S&F2011
	of,of_er   = [0.25e20, 0.14e20]

	# cf,cf_er   = [67.57e20, 4.58e20]  ## From SFD1998
	# of,of_er   = [0.26e20, 0.13e20]

	# OK - Go #
	ebv     = []
	ebver   = []

	nh      = []
	nher    = []

	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []

	for i in range(0, len(src)):
		if (src[i] not in ohsc):
			continue

		# Find the values of ebv353 and Err_ebv353 in small area #
		ci_i  = []

		l     = info['l'][i]
		b     = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (ebv_map[pix] > -0.000001) : # Some pixels not defined
			ci_i.append(ebv_map[pix])

		for x in pl.frange(l-offset, l+offset, dd):
			for y in pl.frange(b-offset, b+offset, dd):
				cosb = np.cos(b*deg2rad)
				cosy = np.cos(y*deg2rad)

				if ( ((x-l)**2 + (y-b)**2) <= offset**2 ):
					# hp.projtext(x, y, '.', lonlat=True, coord='G')
					theta = (90.0 - y)*deg2rad
					phi   = x*deg2rad
					pix   = hp.ang2pix(nside, theta, phi, nest=False)

					if (ebv_map[pix] > -0.000001) :
						ci_i.append(ebv_map[pix])

		vci = list(set(ci_i))
		cnt = len(vci)

		# Calculate mean values of EBV353 #
		val = sum(vci)/float(cnt)
		err = cal_uncertainty_in_mean(vci)

		ebv.append(val)
		ebver.append(err)
	   
		## Calculate the NH from E(B-V) #
		n_h   = cf*val + of
		nh_er = uncertainty_of_product(cf, val, cf_er, err)
		nh_er = np.sqrt(nh_er**2 + of_er**2)

		print n_h, nhi[i], nh_er, nhier[i]

		## N(H2) = (NH-NHI)/2 ##
		nh2 = (n_h-nhi[i]*1e20)/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue

		nh2_er = 0.5*uncertainty_of_diff(nh_er, nhier[i]*1e20)

		## N(H2) ##
		rnh2.append(nh2)
		rnh2_er.append(nh2_er)

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] )
		roh_er.append( noh[src[i]]['noher'] )
		rsrc.append( src[i] )

		# print src[i], n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	return rnh2, rnh2_er, roh, roh_er, rsrc

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def noh_vs_nh2(map_file, info, noh):
	src   = info['src']
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	# TFORM1  = 'EBV       '          /data format of field: 4-byte REAL
	# TTYPE2  = 'N_OBS   '           /label for field   2
	ci_map = hp.read_map(map_file, field = 2)
	nh2, nh2_er, roh, roh_er, rsrc = nh_from_ebv(ci_map, info, noh)

	print len(nh2)
	print len(nh2_er)
	print len(roh)
	print len(roh_er)

	# sys.exit()

	## To Plot ##
	xdata = roh
	ydata = nh2

	# Error bar for x-axis and y-axis
	xerr  = roh_er
	yerr  = nh2_er

	########### MPFIT ############
	xdata = 1.0e14*np.array(xdata)
	ydata = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr = 1.0e14*np.array(xerr)
	yerr = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	xmin = xoh.min()
	xmax = xoh.max()
	plt.hist(xoh, alpha=0.5, label='', color='b', ls='-',  histtype='stepfilled', stacked=False, fill=True, range=(xmin,xmax), bins=12, lw=3)

	plt.title('', fontsize=22)
	plt.ylabel('Number', fontsize=22,fontweight='bold')
	plt.xlabel('$X_{OH} = N(OH)/N(H_{2})$', fontsize=22, fontweight='bold')

	plt.tick_params(axis='x', labelsize=22, pad=8)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=9)
	plt.tick_params(which='minor', length=4)
	plt.legend(loc='upper right', fontsize=22)
	plt.grid(False)

	plt.text(0.05, 15.0, 'Far from 1.0 are l-o-s with very low N(HI) (<3.0e20)', color='blue', fontsize=20)

	plt.tight_layout()
	plt.show()

	##### X(OH) vs N(H2) #####
	plt.errorbar(ydata, xoh, xerr=yerr, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$X_{OH}\ vs\ N_{H_{2}}$')

	plt.title('X$_{OH}$ vs N$_{H_{2}}$', fontsize=30)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.xlabel('$N_{H_{2}} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)

	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(rsrc)):
		plt.annotate('('+str(rsrc[i])+')', xy=(ydata[i], xoh[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )
	plt.show()



	sys.exit()


	## Fit ##
	lguess  = [ 0.66e-7, 0.66e-8 ]
	lguess  = [ 1.e7 ]

	npar    = len(lguess)
	guessp  = np.array(lguess, dtype='float64')
	plimd   = [[False,False]]*npar
	plims   = [[0.,0.]]*npar
	parbase = {'value': 0., 'fixed': 0, 'parname': '', 'limited': [0, 0], 'limits': [0., 0.]}
	pname   = ['slope','offset']
	pfix    = [False]*npar

	parinfo = []
	for i in range(len(guessp)):
		parinfo.append(copy.deepcopy(parbase))

	for i in range(len(guessp)):
		parinfo[i]['value']   = guessp[i]
		parinfo[i]['fixed']   = pfix[i]
		parinfo[i]['parname'] = pname[i]
		parinfo[i]['limited'] = plimd[i]

	x  = xdata.astype(np.float64)
	y  = ydata.astype(np.float64)
	er = yerr.astype(np.float64)

	fa = {'x':x, 'y':y, 'err':er}
	mp = mpfit(myfunc, guessp, parinfo=parinfo, functkw=fa, quiet=True)

	## ********* Results ********* ##
	print '********* Results *********'
	abp   = mp.params
	abper = mp.perror
	for i in range(len(parinfo)):
		print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m  = round(abp[0],10)
	# b  = round(abp[1],10)
	ea = round(abper[0],10)
	# eb = round(abper[1],10)

	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$N_{H_{2}}\ vs\ N_{OH}$')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=4, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='MPFIT linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.title('N$_{H_{2}}$ vs N$_{OH}$', fontsize=30)
	plt.ylabel('$N_{H_{2}}$', fontsize=35)
	plt.xlabel('$N_{OH} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	plt.text(2.0e14,1e21, 'Conversion factor: [68.83e20, 2.74e20]', color='blue', fontsize=20)
	plt.text(0.0,5e21, '$Fit: y = ['+str(m/1e7)+'\pm'+str(ea/1e7) +']\cdot 10^{7} \cdot N_{OH}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# plt.savefig("test.png",bbox_inches='tight')
	for i in range(len(rsrc)):
		# if(oh[i] > 0):
		# plt.annotate('('+str(rsrc[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
		plt.annotate('('+str(rsrc[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )
	plt.show()
	########### END - MPFIT ############

	########### ODR fit ############
	# Create a model for Orthogonal distance regression (ODR) fitting.
	lin_model = Model(lin_fc)
	# Create a RealData object using our initiated data from above.
	data      = RealData(xdata, ydata, sx=xerr, sy=yerr)
	# Set up ODR with the model and data.
	odr       = ODR(data, lin_model, beta0=lguess)
	# Run the regression.
	out       = odr.run()

	## ********* Results ********* ##
	print '********* ODR Results *********'
	abp   = out.beta
	abper = out.sd_beta
	for i in range(1):
		print "%s = %03.8f +/- %03.8f" % ('slope',abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m  = round(abp[0],10)
	# b  = round(abp[1],10)
	ea = round(abper[0],10)
	# eb = round(abper[1],10)

	# plt.plot(xdata,ydata, 'ok', ls='None', marker='.', lw=1, label='Factor $f = N_{HI}$/$N^*_{HI}$')
	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.title('N$_{H_{2}}$ vs N$_{OH}$', fontsize=30)
	plt.ylabel('$N_{H_{2}}$', fontsize=35)
	plt.xlabel('$N_{OH} (cm^{-2}$)', fontsize=35)
	# plt.xlim(-1.0, 4.0)

	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	plt.text(2.0e14,1e21, 'Conversion factor: [68.83e20, 2.74e20]', color='blue', fontsize=20)
	plt.text(0.0,5e21, '$Fit: y = ['+str(m/1e7)+'\pm'+str(ea/1e7) +']\cdot 10^{7} \cdot N_{OH}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()
	########### END - ODR ############


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from Planck r.12, IRAS ~5'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
# info   = read_info_no_co('../../co12/result/26src_no_co_with_sponge.dat')
# lownhi = read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt')
info   = read_nhi_94src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_sponge_prior.txt')

noh = read_noh(fname = '../../oh/result/total_noh65_21src.txt')
# noh = read_noh(fname = '../../oh/result/total_noh67_21src.txt')

print noh

## cal N(H2)
noh_vs_nh2(map_file, info, noh)