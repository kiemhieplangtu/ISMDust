import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import operator
import copy

from numpy    import array
from restore  import restore
from plotting import cplot
from mpfit    import mpfit

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	# model  = p[0] * x + p[1]
	model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Cal. uncertainty in the mean #
 #
 # params list lst List of numbers
 # return float ret Uncertainty in the mean
 # 
 # Author Van Hiep ##
def cal_uncertainty_in_mean(lst):
	n    = len(lst)
	mean = sum(lst)/float(n)

	s    = 0
	for i in range(n):
		s = s + (lst[i] - mean)**2

	s = np.sqrt(s)
	return s/n

## Read info of 26 no-CO sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict infocd 
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_info_no_co(fname = '../../co12/result/26src_no_co_with_sponge.dat'):
	cols = ['idx','src','l','b','ra_icrs','de_icrs','ra_j','de_j', 'oh', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f','f', 'f',    'f',       's',    's',    'i', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Read info of 23 LOW NHI sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict info
 # 
 # version 12/2016
 # Author Van Hiep ##
def read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt'):
	cols = ['idx','src','l', 'b', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f', 'f', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Cal NH from E(B-V), Planck R1.2 #
 #
 # params array ebv_map  Map of E(B-V)
 # params dict  info     Infor of the sources
 #
 # return list info
 # 
 # version 12/2016
 # Author Van Hiep ##
def cal_ebv(ebv_map, info):
	# Define constants #
	deg2rad = np.pi/180.

	## sources
	src = info['src']  ## src

	# Define the width of area #
	beam   = 5.            # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(ebv_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	ebv    = []
	ebver  = []
	nh     = []
	nher   = []

	ci     = {}
	ci_err = {}

	for i in range(0, len(src)):
		# Find the values of ebv353 and Err_ebv353 in small area #
		ci[i]   = []

		l = info['l'][i]
		b = info['b'][i]


		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (ebv_map[pix] > -0.000001) : # Some pixels not defined
			ci[i].append(ebv_map[pix])

		for x in pl.frange(l-offset, l+offset, dd):
			for y in pl.frange(b-offset, b+offset, dd):
				cosb = np.cos(b*deg2rad)
				cosy = np.cos(y*deg2rad)

				if ( ((x-l)**2 + (y-b)**2) <= offset**2 ):
					# hp.projtext(x, y, '.', lonlat=True, coord='G')
					theta = (90.0 - y)*deg2rad
					phi   = x*deg2rad
					pix   = hp.ang2pix(nside, theta, phi, nest=False)

					if (ebv_map[pix] > -0.000001) :
						ci[i].append(ebv_map[pix])

		vci = list(set(ci[i]))
		cnt = len(vci)

		# Calculate mean values of EBV353 #
		val = sum(vci)/float(cnt)
		err = cal_uncertainty_in_mean(vci)

		ebv.append(val)
		ebver.append(err)
	   
		# Calculate the NH from E(B-V) #
		# n_h = val/1.44 # 1e22; (NH = 1.e22*EBV/1.44)
		# n_h = 0.58*val # 1e22
		# err = 0.58*err

		# nh.append(n_h*100.)
		# nher.append(err*100.)

	return ebv, ebver

## Get ebv values and err_ebv values from 26 sources without CO#
 # Than calculate N(H) from Dust
 #
 # params str map_file File of maps
 # params dict info Information of 26 no CO sources
 # params dict lownhi Information of 23 Low NHI sources
 #
 # return void
 # 
 # version 12/2016
 # Author Van Hiep ##	
def cal_nh_from_dust(map_file, info, lownhi):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	thin  = info['thin']
	thinr = info['thin_er']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	## 23 lownhi sources
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']

	# TTYPE1  = 'TAU353  '           / Optical depth at 353GHz                        
	# TTYPE2  = 'ERR_TAU '           / Error on optical depth                         
	# TTYPE3  = 'EBV     '           / E(B-V) color excess                            
	# TTYPE4  = 'RADIANCE'           / Integrated emission                            
	# TTYPE5  = 'TEMP    '           / Dust equilibrium temperature                   
	# TTYPE6  = 'ERR_TEMP'           / Error on T                                     
	# TTYPE7  = 'BETA    '           / Dust emission spectral index                   
	# TTYPE8  = 'ERR_BETA'           / error on Beta  
	ci_map     = hp.read_map(map_file, field = 2)
	ci, cier   = cal_ebv(ci_map, info)
	xci, xcier = cal_ebv(ci_map, lowhi)

	y   = nhi + hi
	x   = ci  + xci

	yer = nhier + hier
	xer = cier  + xcier

	########### MPFIT ############
	xdata = np.array(x)
	ydata = np.array(y)

	# Error bar for x-axis and y-axis
	xerr = np.array(xer)
	yerr = np.array(yer)

	## Fit ##
	lguess  = [0.6, 0.6]
	lguess  = [58.0]

	npar    = len(lguess)
	guessp  = np.array(lguess, dtype='float64')
	plimd   = [[False,False]]*npar
	plims   = [[0.,0.]]*npar
	parbase = {'value': 0., 'fixed': 0, 'parname': '', 'limited': [0, 0], 'limits': [0., 0.]}
	pname   = ['slope','offset']
	pfix    = [False]*npar

	parinfo = []
	for i in range(len(guessp)):
		parinfo.append(copy.deepcopy(parbase))

	for i in range(len(guessp)):
		parinfo[i]['value']   = guessp[i]
		parinfo[i]['fixed']   = pfix[i]
		parinfo[i]['parname'] = pname[i]
		parinfo[i]['limited'] = plimd[i]

	x  = xdata.astype(np.float64)
	y  = ydata.astype(np.float64)
	er = yerr.astype(np.float64)

	fa = {'x':x, 'y':y, 'err':er}
	mp = mpfit(myfunc, guessp, parinfo=parinfo, functkw=fa, quiet=True)

	## ********* Results ********* ##
	print '********* Results *********'
	abp   = mp.params
	abper = mp.perror
	for i in range(len(parinfo)):
		print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m  = round(abp[0],2)
	# b  = round(abp[1],10)
	ea = round(abper[0],2)
	# eb = round(abper[1],10)

	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='$E(B-V) vs N_{HI}$')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='MPFIT linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	# plt.title('Correlation between Total HI column densities $N_{HI}$ and \n HI optically thin column densities $N^*_{HI}$ along 94 (Millennium Survey & 21-SPONGE) lines-of-sight', fontsize=30)
	plt.xlabel('$E(B-V)$', fontsize=35)
	plt.ylabel('$N_{HI}/10^{20} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)

	# plt.text(15.0,0.000005, '$f = ['+str(m)+'\pm'+str(ea) +']\cdot log_{10}(N^*_{HI}/10^{20}) + ['+str(b)+'\pm'+str(eb)+']$', color='blue', fontsize=20)
	plt.text(0.01, 32., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{20} E(B-V)$', color='blue', fontsize=20)
	plt.text(0.01, 35., r'$N_{H} = 58\cdot10^{20}\cdot E(B-V)\ [cm^{-2}mag^{-1}]$', color='k', fontsize=17)
	plt.legend(loc='upper left', fontsize=18)
	# plt.savefig("test.png",bbox_inches='tight')
	for i in range(len(src)):
		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )
	plt.show()
	########### END - MPFIT ############

#================= MAIN ========================#
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'
# map_file = pth + 'HFI_CompMap_DustOpacity_2048_R1.10.fits'
# map_file = pth + 'lambda_sfd_ebv.fits'  ## E(B-V) from SFD et al. 1998

## Infor of 26 src without CO && 23 Low NHI sources ##
info     = read_info_no_co('../../co12/result/26src_no_co_with_sponge.dat')
lowhi    = read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt')

cal_nh_from_dust(map_file, info, lowhi)
# plot_patches(map_file, info)