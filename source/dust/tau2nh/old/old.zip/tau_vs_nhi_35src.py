import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit

## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 #
 # return list info
 # 
 # version 12/2016
 # Author Van Hiep ##
def nh_from_tau353(tau_map, err_map, info):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']

	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown

	# Define the width of area #
	beam   = 5.             # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(tau_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	tau353 = []
	tau_er = []
	for i in range(len(src)):
		# Find the values of Tau353 and Err_tau353 in small area #
		l     = info['l'][i]
		b     = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau353.append(tau_map[pix])
			tau_er.append(err_map[pix])
		else:
			print "Error! Error!"
			sys.exit()

	return tau353, tau_er

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict info   Information of lowNHI sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_vs_tau(map_file, info,lownhi):
	fk     = 4.77e-7 ## tau353 = 4.77e-27 N(HI) 
	plws   = 8.40e-7 ## tau353 = 8.4e-27 N(H) -> Whole sky
	pllow  = 6.60e-7 ## tau353 = 6.6e-27 N(H) -> Low NHI

	## 19 sources without CO & without OH
	src    = info['src']
	nhi    = info['nhi']
	thin   = info['thin']
	thinr  = info['thin_er']
	nhier  = info['nhi_er']
	cnm    = info['cnm']
	cnmer  = info['cnm_er']
	wnm    = info['wnm']
	wnmer  = info['wnm_er']
	xl     = info['l']
	xb     = info['b']

	## 16 lownhi sources
	lsc    = lownhi['src']
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']
	lwnm   = lownhi['wnm']
	lwnmer = lownhi['wnm_er']
	lcnm   = lownhi['cnm']
	lcnmer = lownhi['cnm_er']
	zl     = lownhi['l']
	zb     = lownhi['b']

	# tau353 map, err_tau353 map and resolution #
	tau_map  = hp.read_map(map_file, field = 0)
	err_map  = hp.read_map(map_file, field = 1)

	tau353, tau_er   = nh_from_tau353(tau_map, err_map, info)
	ltau353, ltau_er = nh_from_tau353(tau_map, err_map, lownhi)

	#### To Plot ##
	ydata = nhi    + hi
	xdata = tau353 + ltau353
	los   = src    + lsc

	### Error bar for x-axis and y-axis
	yerr  = nhier  + hier
	xerr  = tau_er + ltau_er

	########### MPFIT ############
	xdata = np.array(xdata)
	ydata = np.array(ydata)

	### Error bar for x-axis and y-axis
	xerr  = np.array(xerr)
	yerr  = np.array(yerr)

	### Correlation: Radiance and NH ##
	coxy      = md.cov_xy(ydata,xdata)
	varx      = md.var(xdata)
	vary      = md.var(ydata)
	rho       = coxy/varx/vary
	
	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdata, ydata), ', ', rho
	print ''

	plt.plot(np.array(xdata)/np.array(varx), np.array(ydata)/np.array(vary), 'r*')
	plt.xlabel('X/varx')
	plt.ylabel('Y/vary')
	plt.show()
	### End - Correlation: Radiance and NH ##

	## Fit ##
	lguess  = [ 0.84e-7, 0.84e-8]
	lguess  = [ 1.0/6.778e-7]

	xfit, yfit, mu, sig, m, ea = md.do_linODRfit(xdata, ydata, xerr, yerr, lguess=lguess)

	# plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='data')
	# plt.plot([6.0e-7,3.5e-5], [6.0e-7/pllow,3.5e-5/pllow], 'k-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Planck collab. 2014')
	# plt.plot(xfit, mu, 'b-', mew=2, linewidth=4, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Linear fit')
	# plt.plot([6.0e-7,3.5e-5], [6.0e-7/fk,3.5e-5/fk], 'r-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Fukui et al. 2015')
	# plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	# plt.title(r'$\tau_{353}$ and total $N_{H}$', fontsize=30)
	# plt.xlabel(r'$\tau_{353}$', fontsize=35)
	# plt.ylabel('$N_{H} [10^{20} cm^{-2}$]', fontsize=35)
	# plt.ylim(0.8, 90.0)
	# plt.xlim(5.8e-7, 3.8e-5)

	# plt.grid(True)
	# plt.tick_params(axis='x', labelsize=18)
	# plt.tick_params(axis='y', labelsize=15)
	# # plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	# plt.yscale('log')
	# plt.xscale('log')

	# # plt.text(6.3,1.5e-6, 'pearson_coeff = '+str(pc), color='blue', fontsize=20)
	# # plt.text(6.3,1e-6, '$Fit: f = ['+str(m)+'\pm'+str(ea) +']\cdot (N_{HI}/10^{20})$', color='blue', fontsize=20)
	# plt.text(5.0,1e-6, '19 data points without CO and OH detection \n16 low-$N_{HI}$ data points without OH, but no data on CO', color='blue', fontsize=20)
	# # plt.text(12.0,0.000005, '$f = ['+str(m)+'\pm'+str(ea) +']\cdot (N_{HI}/10^{20}) + ['+str(b)+'\pm'+str(eb)+']\cdot10^{20}$', color='blue', fontsize=20)
	# # plt.text(0.8,0.000008, r'Fukui: $\tau_{353} = 4.77 \times 10^{-27} \cdot N_{HI}$', color='blue', fontsize=20)
	# # plt.text(0.8,0.0000067, r'Planck - Whole sky: $\tau_{353} = 8.4 \times 10^{-27} \cdot N_{HI}$', color='blue', fontsize=20)
	# plt.text(2.5e-6,1., r'Linear fit: $\tau_{353} = [6.8\pm0.3] \times 10^{-27} \cdot N_{H}$', color='blue', fontsize=20)
	# plt.text(2.5e-6,1.3, r'Planck collab. 2013: $\tau_{353} = [6.6\pm1.7] \times 10^{-27} \cdot N_{H}$', color='blue', fontsize=20)
	# plt.text(2.5e-6,1.7, r'Fukui et al. 2015: $\tau_{353} = 4.77 \times 10^{-27} \cdot N_{H}$', color='blue', fontsize=20)
	# plt.legend(loc='upper left', fontsize=18)
	# plt.show()
	# ########### END - ODR ############

	# print '1./m, ea/m/m', 1./m, ea/m/m


	# for i in range(len(los)):
	# 	nh = m*xdata[i]
	# 	print i, los[i],'     \t', xdata[i],'\t', ydata[i],'\t', nh,'\t', nh-ydata[i]

	# # Plot for paper ##
	# mpl.rcParams['axes.linewidth'] = 1.5
	# fig          = plt.figure(figsize=(10,5))
	# ax           = fig.add_subplot(111); #ax.set_rasterized(True)                                 
	# major_xticks = np.arange(1.e-7, 1.e-4, 1.e-5)
	# minor_xticks = np.arange(1.e-7, 1.e-4, 5.e-6)
	# major_yticks = np.arange(1., 80., 10.)                                              
	# minor_yticks = np.arange(1., 80., 5.0)

	# plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='k', marker='o', ls='None', markersize=6, markeredgecolor='k', markeredgewidth=1, label='data')
	# plt.plot([6.0e-7,3.5e-5], [6.0e-7/pllow,3.5e-5/pllow], 'k:', mew=2, linewidth=2, marker='o', markerfacecolor='b', markersize=0, label='Planck collab. 2014')
	# plt.plot(xfit, mu, 'k-', mew=2, linewidth=4, marker='o', markerfacecolor='b', markersize=0, label='Linear fit')
	# plt.plot([6.0e-7,3.5e-5], [6.0e-7/fk,3.5e-5/fk], 'k-.', mew=2, linewidth=2, marker='o', markerfacecolor='b', markersize=0, label='Fukui et al. 2015')
	# plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	# plt.title('', fontsize=30)
	# plt.xlabel(r'$\mathrm{\tau_{353}}$', fontsize=22)
	# plt.ylabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=20)

	# plt.tick_params(axis='y', labelsize=18)
	# plt.tick_params(axis='x', labelsize=18)
	# # plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))	

	# ax.set_xticks(major_xticks)                                                       
	# ax.set_xticks(minor_xticks, minor=True)                                           
	# ax.set_yticks(major_yticks)                                                       
	# ax.set_yticks(minor_yticks, minor=True)
	# plt.tick_params(axis='x', labelsize=16, pad=5)
	# plt.tick_params(axis='y', labelsize=16)
	# plt.tick_params(which='both', width=1.5)
	# plt.tick_params(which='major', length=9)
	# plt.tick_params(which='minor', length=4)

	# plt.ylim(0.8, 90.0)
	# plt.xlim(5.8e-7, 3.8e-5)
	# plt.yscale('log')
	# plt.xscale('log')

	# plt.tight_layout()
	# # plt.legend(loc='upper left', fontsize=18)
	# plt.savefig('tau_vs_nh.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	# plt.show()



	## PLOT sigma vs NHI ##
	# From Planck data to overplot
	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/sigma_e353_vs_N_H_Xco1.txt')
	nh1    = np.array(nh)
	sig1   = np.array(sig)
	er1    = np.array(sd_sig)

	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/sigma_e353_vs_N_H_Xco2.txt')
	nh2    = np.array(nh)
	sig2   = np.array(sig)
	er2    = np.array(sd_sig)

	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/sigma_e353_vs_N_H_Xco3.txt')
	nh3    = np.array(nh)
	sig3   = np.array(sig)
	er3    = np.array(sd_sig)

	r1     = np.array(tau353)/np.array(nhi)
	r1er   = md.uncertainty_of_ratio(np.array(tau353), np.array(nhi), np.array(tau_er), np.array(nhier))

	r2     = np.array(ltau353)/np.array(hi)
	r2er   = md.uncertainty_of_ratio(np.array(ltau353), np.array(hi), np.array(ltau_er), np.array(hier))

	r2mean = np.mean(r2)
	print 'Sigma at low N(HI): ', r2mean

	fltr   = np.extract([(nh2>1.) & (nh2<4.)], sig2)
	pl_av  = fltr.mean()

	r1     = r1*1e7
	r2     = r2*1e7
	rs     = np.concatenate([r1, r2])
	nh     = np.concatenate([nhi, hi])
	
	fltr   = np.extract([(nh>1.) & (nh<4.)], rs)
	sg_av  = fltr.mean()


	## PLOT - sigma353 vs NH ##
	mpl.rcParams['axes.linewidth'] = 1.5
	fig          = plt.figure(figsize=(16,10))
	ax           = fig.add_subplot(111); #ax.set_rasterized(True)

	mks = 8
	fts = 36

	# major_xticks = np.arange(0., 500., 10.)
	# minor_xticks = np.arange(0., 500., 10.)
	major_yticks = np.arange(0., 22., 2.)                                              
	minor_yticks = np.arange(0., 22., 1.)

	xerb1, = plt.plot(nh1, sig1, color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 1\cdot 10^{20}$')
	plt.errorbar(nh1, sig1, xerr=nh1*0., yerr=er1*0., color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 1\cdot 10^{20}$')
	
	xerb2, = plt.plot(nh3, sig3, color='purple', marker='o', ls='None', markersize=mks, markeredgecolor='purple', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 3\cdot 10^{20}$')
	plt.errorbar(nh3, sig3, xerr=nh3*0., yerr=er3*0., color='purple', marker='o', ls='None', markersize=mks, markeredgecolor='purple', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 3\cdot 10^{20}$')

	xerb3, = plt.plot(nh2, sig2, color='0', marker='o', ls='None', markersize=mks, markeredgecolor='k', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 2\cdot 10^{20}$')
	plt.errorbar(nh2, sig2, xerr=nh2*0., yerr=er2, color='0', marker='o', ls='None', markersize=mks, markeredgecolor='k', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 2\cdot 10^{20}$')

	xerb4, = plt.plot(nhi, r1, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 19 sightlines without CO and OH detection')
	plt.errorbar(nhi, r1, xerr=nhier, yerr=r1er*1e7, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 19 sightlines without CO and OH detection')
	plt.errorbar(hi, r2, xerr=hier, yerr=r2er*1e7, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 16 low $N_{HI}$ sightlines (no OH detection, but no CO data)')
	
	plt.plot([0.,500.], [sg_av,sg_av], 'k', mew=2, linewidth=2, linestyle='-.', marker='o', markerfacecolor='b', markersize=0, label=r'Mean $\sigma_{353}$ for Low $N_{HI}$')
	plt.plot([0.,500.], [pl_av,pl_av], 'k', mew=2, linewidth=2, linestyle='--', marker='o', markerfacecolor='b', markersize=0, label=r'Mean $\sigma_{353}$ for Low $N_{HI}$ from Planck Collaboration 2014')

	plt.title('', fontsize=0)
	plt.ylabel(r'$\mathrm{\sigma_{353} = \tau_{353}/N_{H}\ [10^{-27}cm^{2}H^{-1}]} $', fontsize=fts, fontweight='normal')
	plt.xlabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=fts, fontweight='normal')
	
	plt.tick_params(axis='x', labelsize=20)
	plt.tick_params(axis='y', labelsize=15)
	# plt.yscale('log')
	plt.xscale('log')
                                         
	ax.set_yticks(major_yticks)                                                       
	ax.set_yticks(minor_yticks, minor=True)
	plt.tick_params(axis='x', labelsize=22, pad=7)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=12)
	plt.tick_params(which='minor', length=6)
	plt.grid(False)

	plt.xlim(0.7, 500.0)
	plt.ylim(2.,20.)

	axbox = ax.get_position()
	leg   = plt.legend([xerb4, xerb1, xerb3, xerb2], [r'$\mathrm{This\ work}$',\
	 r'$\mathrm{X_{CO}}$$\mathrm{{=}1}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$',\
	  r'$\mathrm{X_{CO}}$$\mathrm{{=}2}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$',\
	   r'$\mathrm{X_{CO}}$$\mathrm{{=}3}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$'],\
	    fontsize=23, loc=(axbox.x0-0.11, axbox.y0+0.6), numpoints=1)
	leg.get_frame().set_linewidth(0.0)

	plt.tight_layout()
	
	plt.savefig('sig353_vs_nh.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	plt.show()
	## END - PLOT ##

	sys.exit()




	## PLOT sigma vs CNM fraction: CNM/NHI ##
	tau353  = np.array(tau353)
	tau_er  = np.array(tau_er)
	nhi     = np.array(nhi)
	nhier   = np.array(nhier)
	cnm     = np.array(cnm)
	cnmer   = np.array(cnmer)
	wnm     = np.array(wnm)
	wnmer   = np.array(wnmer)

	ltau353 = np.array(ltau353)
	ltau_er = np.array(ltau_er)
	hi      = np.array(hi)
	hier    = np.array(hier)
	lcnm    = np.array(lcnm)
	lcnmer  = np.array(lcnmer)
	lwnm    = np.array(lwnm)
	lwnmer  = np.array(lwnmer)

	r1      = tau353/nhi
	r1er    = md.uncertainty_of_ratio(tau353, nhi, tau_er, nhier)
	fcnm1   = cnm/nhi
	f1er    = md.uncertainty_of_ratio(cnm, nhi, cnmer, nhier)

	r2      = ltau353/hi
	r2er    = md.uncertainty_of_ratio(ltau353, hi, ltau_er, hier)
	fcnm2   = lcnm/hi
	f2er    = md.uncertainty_of_ratio(lcnm, hi, lcnmer, hier)

	plt.errorbar(fcnm1, r1, xerr=f1er, yerr=r1er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='No CO and no OH: 19 l.o.s')

	# filter = (fcnm2>0.)
	plt.errorbar(fcnm2, r2, xerr=f2er, yerr=r2er, color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='low N(HI): 23 l.o.s')
	# plt.plot([0.,35.], [0.,35.*pllow], 'k-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Planck - factor for Low N(HI)')

	plt.title(r'$\sigma_{353}$ and CNM fraction', fontsize=30)
	plt.ylabel(r'$sigma = \tau_{353}/N_{HI}$', fontsize=35)
	plt.xlabel('$f=CNM/N_{HI}$', fontsize=35)
	# plt.xlim(-1.0, 4.0)

	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	# plt.yscale('log')
	# plt.xscale('log')

	plt.legend(loc='upper left', fontsize=18)

	for i in range(len(src)):
		# if(oh[i] > 0):
		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(fcnm1[i], r1[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )

	for i in range(len(lsc)):
		if(fcnm2[i] > 0):
			plt.annotate('('+str(lsc[i])+', '+ str(zl[i])+', '+str(zb[i])+')', xy=(fcnm2[i], r2[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )

	plt.show()
	## END - PLOT ##

	## Plot sigma vs b ##
	plt.errorbar(np.abs(xb), r1, xerr=0.*f1er, yerr=r1er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='No CO and no OH: 19 l.o.s')
	plt.errorbar(np.abs(zb), r2, xerr=0.*f2er, yerr=r2er, color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='low N(HI): 23 l.o.s')
	# plt.plot([0.,35.], [0.,35.*pllow], 'k-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Planck - factor for Low N(HI)')

	plt.title(r'$\sigma_{353}$ vs $|b|$', fontsize=30)
	plt.ylabel(r'$sigma = \tau_{353}/N_{HI}$', fontsize=35)
	plt.xlabel('$|b(^o)$|', fontsize=35)
	# plt.xlim(-1.0, 4.0)

	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	# plt.yscale('log')
	# plt.xscale('log')

	plt.legend(loc='upper left', fontsize=18)

	for i in range(len(src)):
		# if(oh[i] > 0):
		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(np.abs(xb[i]), r1[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )

	for i in range(len(lsc)):
		# if(oh[i] > 0):
		plt.annotate('('+str(lsc[i])+', '+ str(zl[i])+', '+str(zb[i])+')', xy=(np.abs(zb[i]), r2[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )

	plt.show()
	## END - PLOT ##


	sys.exit()







	########### ODR fit ############
	xdata = ydata
	ydata = xdata
	xerr  = yerr
	yerr  = xerr

	# x  = xdata.astype(np.float64)
	# y  = ydata.astype(np.float64)
	# er = yerr.astype(np.float64)

	# # Create a model for Orthogonal distance regression (ODR) fitting.
	# lin_model = Model(lin_fc)
	# # Create a RealData object using our initiated data from above.
	# data      = RealData(xdata, ydata, sx=xerr, sy=yerr)
	# # Set up ODR with the model and data.
	# odr       = ODR(data, lin_model, beta0=[1.0e5])
	# # Run the regression.
	# out       = odr.run()

	xm   = 1.0/m
	xmer = md.uncertainty_of_ratio(1.0, m, 0.0, ea)

	print "%s = %03.8f +/- %03.8f" % ('slope',xm,xmer)

	## Plot ##
	a     = np.array([ xm-xmer, xm+xmer ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m     = round(abp[0],10)
	# b   = round(abp[1],10)
	ea    = round(abper[0],10)
	# eb  = round(abper[1],10)

	plt.errorbar(tau353, nhi, yerr=nhier, xerr=tau_er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='data')
	plt.errorbar(ltau353, hi, yerr=hier, xerr=ltau_er, color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=3, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	# plt.plot([0.,35.], [0.,35.*fk], 'r-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Fukui')
	# plt.plot([0.,35.], [0.,35.*plws], 'm-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Planck - whole sky factor')
	# plt.plot([0.,35.], [0.,35.*pllow], 'k-', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='Planck - factor for Low N(HI)')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.title(r'$\tau_{353}$ and $N_{HI}$', fontsize=30)
	plt.xlabel(r'$\tau_{353}$', fontsize=35)
	plt.ylabel('$N_{HI}/10^{20} (cm^{-2}$)', fontsize=35)
	# plt.xlim(-1.0, 4.0)

	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	plt.yscale('log')
	plt.xscale('log')

	plt.text(6.3,1.5e-6, 'pearson_coeff = '+str(pc), color='blue', fontsize=20)
	plt.text(6.3,1e-6, '$Fit: f = ['+str(m)+'\pm'+str(ea) +']\cdot (N_{HI}/10^{20})$', color='blue', fontsize=20)
	# plt.text(12.0,0.000005, '$f = ['+str(m)+'\pm'+str(ea) +']\cdot (N_{HI}/10^{20}) + ['+str(b)+'\pm'+str(eb)+']\cdot10^{20}$', color='blue', fontsize=20)
	plt.text(0.8,0.000008, r'Fukui: $\tau_{353} = 4.77 \times 10^{-27} \cdot N_{HI}$', color='blue', fontsize=20)
	plt.text(0.8,0.0000067, r'Planck - Whole sky: $\tau_{353} = 8.4 \times 10^{-27} \cdot N_{HI}$', color='blue', fontsize=20)
	plt.text(0.8,0.0000055, r'Planck - Low N(HI): $\tau_{353} = 6.6 \times 10^{-27} \cdot N_{HI}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(src)):
		# if(oh[i] > 0):
		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )
	plt.show()
	########### END - ODR ############


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 19 sources with noCO, noOH and 23 src low NHI- l/b/name && #
info   = md.read_19src_noco_nooh(fname = '../../oh/result/19src_noCO_noOH.txt')
lownhi = md.read_23rc_lownhi(fname = '../../oh/result/16src_lowNHI.txt')

## cal N(H)
nh_vs_tau(map_file, info, lownhi)