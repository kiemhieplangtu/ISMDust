import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit

## Get Radiance #
 #
 # params str map_file  File of Radiance Map
 # params dict  info   Infor of the sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_radiance(tau_map, tauer_map, r_map, info):
	# Define constants #
	deg2rad = np.pi/180.

	fct     = 0.0276
	fct_er  = 0.00072

	## sources
	src     = info['src']  ## src

	# Define the width of area #
	beam    = 5.             # Beam = 36'
	dbeam   = beam/120.0     # Beam = 36' -> dbeam = beam/60/2 in degree
	offset  = dbeam          # degree

	nside   = hp.get_nside(r_map)
	res     = hp.nside2resol(nside, arcmin=False)
	dd      = res/deg2rad/10.0

	# OK - Go #
	r      = []
	rer    = []
	for i in range(len(src)):
		l  = info['l'][i]
		b  = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (r_map[pix] > -0.000001) : # Some pixels not defined
			xtau   = tau_map[pix]
			xtauer = tauer_map[pix]
			val    = r_map[pix]

			d1     = fct_er/fct
			d2     = xtauer/xtau
			dr     = np.sqrt(d1**2 + d2**2)
			err    = val*dr           ## Error of Radiance

		r.append(val)
		rer.append(err)

	return r, rer

## Get NH from radiance #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 23 low-nhi sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep ##	
def nh_from_radiance(map_file, info, lownhi):
	## 19 sources without CO & without OH
	src    = info['src']  ## 19 src without CO & OH
	nhi    = info['nhi']
	thin   = info['thin']
	thinr  = info['thin_er']
	nhier  = info['nhi_er']
	cnm    = info['cnm']
	cnmer  = info['cnm_er']
	wnm    = info['wnm']
	wnmer  = info['wnm_er']
	xl     = info['l']
	xb     = info['b']

	## 16 lownhi sources
	lsc    = lownhi['src']
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']
	lwnm   = lownhi['wnm']
	lwnmer = lownhi['wnm_er']
	lcnm   = lownhi['cnm']
	lcnmer = lownhi['cnm_er']
	zl     = lownhi['l']
	zb     = lownhi['b']

	# Radiance map, err_R map and resolution #
	tau_map   = hp.read_map(map_file, field = 0)
	tauer_map = hp.read_map(map_file, field = 1)
	r_map     = hp.read_map(map_file, field = 3)
	
	r, r_er   = get_radiance(tau_map, tauer_map, r_map, info)
	lr, lr_er = get_radiance(tau_map, tauer_map, r_map, lownhi)

	## To Plot ##
	ydata     = nhi + hi
	xdata     = r   + lr
	los       = src + lsc

	## Error bar for x-axis and y-axis ##
	yerr      = nhier + hier
	xerr      = r_er  + lr_er

	### Correlation: Radiance and NH ##
	coxy      = md.cov_xy(ydata,xdata)
	varx      = md.var(xdata)
	vary      = md.var(ydata)
	rho       = coxy/varx/vary
	
	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdata, ydata), ', ', rho
	print ''

	# plt.plot(np.array(xdata)/np.array(varx), np.array(ydata)/np.array(vary), 'r*')
	# plt.xlabel('X/varx')
	# plt.ylabel('Y/vary')
	# plt.show()
	### End - Correlation: Radiance and NH ##

	########### MPFIT ############
	xdata = 1.e-4*np.array(xdata)*1.0e11   ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	ydata = np.array(ydata)         ## 1e20

	# Error bar for x-axis and y-axis
	xerr  = 1.e-4*np.array(xerr)*1.0e11     ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	yerr  = np.array(yerr)           ## 1e20

	########### MPFIT fit ############
	# xfit, yfit, mu, sig, m, ea, b, eb = md.do_linMPfit(xdata, ydata, xerr, yerr, lguess=[3.0, 1.0])

	########### ODR fit ############
	xfit, yfit, mu, sig, m, ea, b, eb = md.do_linODRfit(xdata, ydata, xerr, yerr, lguess=[3.0, 1.0])

	# plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='data')
	# plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	# plt.fill_between(xfit, mu-sig, mu+sig, color='0.5', alpha=0.5)

	# plt.title('', fontsize=30)
	# plt.xlabel('$Radiance\ [10^{-11} Wcm^{-2}sr^{-1}]$', fontsize=35)
	# plt.ylabel('$N_{HI} [10^{20} cm^{-2}]$', fontsize=35)
	# plt.xlim(0.2, 10.0)
	# # plt.ylim(-1.0, 6.0)
	# plt.grid(True)
	# plt.tick_params(axis='x', labelsize=18)
	# plt.tick_params(axis='y', labelsize=15)
	# # plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))
	# plt.yscale('log')
	# plt.xscale('log')

	# plt.text(0.21, 12., '$N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R + ['+str(b)+'\pm'+str(eb)+']\cdot10^{20}$', color='blue', fontsize=20)
	# plt.text(0.21, 10, '(Data points with no CO and OH detected)', color='k', fontsize=20)
	# # plt.text(0.001, 12., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R$', color='blue', fontsize=20)
	# plt.legend(loc='upper left', fontsize=18)
	# plt.show()
	# ########### END - ODR ############

	# for i in range(len(los)):
	# 	nh = 4.046e31*xdata[i]/1e11+0.09269e20
	# 	nh = nh/1e20
	# 	print i, los[i],'     \t', xdata[i],'\t', ydata[i],'\t', nh,'\t', nh-ydata[i]

	# # Plot for paper ##
	# mpl.rcParams['axes.linewidth'] = 1.5
	# fig          = plt.figure(figsize=(10,5))
	# ax           = fig.add_subplot(111); #ax.set_rasterized(True)                                 
	# major_xticks = np.arange(0., 12., 10.)
	# minor_xticks = np.arange(0., 12., 5.)
	# major_yticks = np.arange(0., 80., 10.)                                              
	# minor_yticks = np.arange(0., 80., 5.0)

	# plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='k', marker='o', ls='None', markersize=6, markeredgecolor='k', markeredgewidth=1, label='data')
	# plt.plot(xfit, mu, '-k', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='k', markersize=0, label='ODR linear fit')
	# plt.fill_between(xfit, mu-sig, mu+sig, color='0.5', alpha=0.5)

	# plt.title('', fontsize=0)
	# plt.xlabel(r'$\mathrm{\mathcal{R}\ [10^{-11} Wcm^{-2}sr^{-1}]}$', fontsize=18)
	# plt.ylabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=20)
	
	# plt.tick_params(axis='y', labelsize=18)
	# plt.tick_params(axis='x', labelsize=18)
	# # plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))	

	# ax.set_xticks(major_xticks)                                                       
	# ax.set_xticks(minor_xticks, minor=True)                                           
	# ax.set_yticks(major_yticks)                                                       
	# ax.set_yticks(minor_yticks, minor=True)
	# plt.tick_params(axis='x', labelsize=16, pad=5)
	# plt.tick_params(axis='y', labelsize=16)
	# plt.tick_params(which='both', width=1.5)
	# plt.tick_params(which='major', length=9)
	# plt.tick_params(which='minor', length=4)

	# plt.xlim(0.2, 11.)
	# plt.ylim(0.8, 40.0)
	# plt.yscale('log')
	# plt.xscale('log')

	# plt.tight_layout()
	# # plt.legend(loc='upper left', fontsize=18)
	# plt.savefig('r_vs_nh.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	# plt.show()

	
	## PLOT sigma vs NHI ##
	# From Planck data to overplot
	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/L_H_vs_N_H_Xco1.txt')
	nh1     = np.array(nh)
	sig1    = np.array(sig)
	er1     = np.array(sd_sig)

	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/L_H_vs_N_H_Xco2.txt')
	nh2     = np.array(nh)
	sig2    = np.array(sig)
	er2     = np.array(sd_sig)

	[nh, sig, sd_sig] = md.read_planck_sigma_vs_nh(fname = 'marc_data/L_H_vs_N_H_Xco3.txt')
	nh3     = np.array(nh)
	sig3    = np.array(sig)
	er3     = np.array(sd_sig)

	r353    = np.array(r)
	r_er    = np.array(r_er)
	nhi     = np.array(nhi)
	nhier   = np.array(nhier)
	cnm     = np.array(cnm)
	cnmer   = np.array(cnmer)
	wnm     = np.array(wnm)
	wnmer   = np.array(wnmer)

	lr353   = np.array(lr)
	lr_er   = np.array(lr_er)
	hi      = np.array(hi)
	hier    = np.array(hier)
	lcnm    = np.array(lcnm)
	lcnmer  = np.array(lcnmer)
	lwnm    = np.array(lwnm)
	lwnmer  = np.array(lwnmer)

	r1      = r353*4.*3.14159/nhi
	r1er    = md.uncertainty_of_ratio(r353, nhi, r_er, nhier)
	fcnm1   = cnm/nhi
	f1er    = md.uncertainty_of_ratio(cnm, nhi, cnmer, nhier)

	r2      = lr353*4.*3.14159/hi
	r2er    = md.uncertainty_of_ratio(lr353, hi, lr_er, hier)
	fcnm2   = lcnm/hi
	f2er    = md.uncertainty_of_ratio(lcnm, hi, lcnmer, hier)

	r2mean  = np.mean(r2)
	print 'Sigma at low N(HI): ', r2mean

	fltr    = np.extract([(nh2>1.) & (nh2<4.)], sig2)
	pl_av   = fltr.mean()

	print pl_av

	r1      = r1*1e7
	r2      = r2*1e7
	r1er    = r1er*1e7*4.*3.14159
	r2er    = r2er*1e7*4.*3.14159
	rs      = np.concatenate([r1, r2])
	nh      = np.concatenate([nhi, hi])
	
	fltr    = np.extract([(nh>1.) & (nh<4.)], rs)
	r_av    = fltr.mean()

	## Plot LH vs NHI ###
	# plt.rc('font', weight='bold')
	# plt.rc('text', usetex=True)
	# plt.rcParams['text.latex.preamble'] = [r'\usepackage{sfmath} \boldmath']

	# plt.rc('text', usetex=True)
	# plt.rc('axes', linewidth=2)
	# plt.rc('font', weight='bold')

	mpl.rcParams['axes.linewidth'] = 1.5
	fig          = plt.figure(figsize=(16,10))
	ax           = fig.add_subplot(111); #ax.set_rasterized(True)

	mks = 8
	fts = 36

	# major_xticks = np.arange(0., 500., 10.)
	# minor_xticks = np.arange(0., 500., 10.)
	major_yticks = np.arange(1., 11., 1.)                                              
	minor_yticks = np.arange(1., 11., 0.5)


	plt.errorbar(nh1, sig1, xerr=nh1*0., yerr=er1*0., color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 1\cdot 10^{20}$')
	xerb1,  = plt.plot(nh1, sig1, color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 1\cdot 10^{20}$')
	
	plt.errorbar(nh3, sig3, xerr=nh3*0., yerr=er3*0., color='purple', marker='o', ls='None', markersize=mks, markeredgecolor='purple', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 3\cdot 10^{20}$')
	xerb2,  = plt.plot(nh3, sig3, color='purple', marker='o', ls='None', markersize=mks, markeredgecolor='purple', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 3\cdot 10^{20}$')
	
	plt.errorbar(nh2, sig2, xerr=nh2*0., yerr=er2, color='0', marker='o', ls='None', markersize=mks, markeredgecolor='k', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 2\cdot 10^{20}$')
	xerb3,  = plt.plot(nh2, sig2, color='0', marker='o', ls='None', markersize=mks, markeredgecolor='k', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 2\cdot 10^{20}$')

	plt.errorbar(nhi, r1, xerr=nhier, yerr=r1er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 19 sightlines without CO and OH detection')
	plt.errorbar(hi, r2, xerr=hier, yerr=r2er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 16 low $N_{HI}$ sightlines (no OH detection, but no CO data)')
	xerb4,  = plt.plot(hi, r2, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 16 low $N_{HI}$ sightlines (no OH detection, but no CO data)')
	
	plt.plot([0.,500.], [r_av,r_av], 'k', mew=2, linewidth=2, linestyle='-.', marker='o', markerfacecolor='b', markersize=0, label=r'Mean $L_{H}$ for Low $N_{HI}$')
	plt.plot([0.,500.], [pl_av,pl_av], 'k', mew=2, linewidth=2, linestyle='--', marker='o', markerfacecolor='b', markersize=0, label=r'Mean $L_{H}$ for Low $N_{HI}$ from Planck Collaboration 2014')

	plt.title('', fontsize=0)
	plt.ylabel(r'$\mathrm{L_{H} = 4\pi \mathcal{R}/N_{H}\ [10^{-31}WH^{-1}]} $', fontsize=fts, fontweight='normal')
	plt.xlabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=fts, fontweight='normal')
	
	plt.tick_params(axis='x', labelsize=20)
	plt.tick_params(axis='y', labelsize=15)
	# plt.yscale('log')
	plt.xscale('log')
                                         
	ax.set_yticks(major_yticks)                                                       
	ax.set_yticks(minor_yticks, minor=True)
	plt.tick_params(axis='x', labelsize=22, pad=7)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=12)
	plt.tick_params(which='minor', length=6)
	plt.grid(False)

	plt.xlim(0.7, 500.0)
	plt.ylim(1.,10.)

	axbox = ax.get_position()
	leg   = plt.legend([xerb4, xerb1, xerb3, xerb2], [r'$\mathrm{This\ work}$', r'$\mathrm{X_{CO}}$$\mathrm{=1}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$', \
		r'$\mathrm{X_{CO}}$$\mathrm{=2}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$',\
		 r'$\mathrm{X_{CO}}$$\mathrm{=3}$$\times$$\mathrm{10}$$^{20}$ $\mathrm{(PLC2014a)}$'], \
		 fontsize=23, loc=(axbox.x0-0.11, axbox.y0+0.6), numpoints=1)
	leg.get_frame().set_linewidth(0.0)

	plt.tight_layout()
	
	plt.savefig('LH_vs_nh.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	plt.show()
	## END - PLOT ##

	sys.exit()

	plt.errorbar(nh1, sig1*nh1, xerr=nh1*0., yerr=er1*0., color='b', marker='o', ls='None', markersize=mks, markeredgecolor='b', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 1\cdot 10^{20}$')
	plt.errorbar(nh3, sig3*nh3, xerr=nh3*0., yerr=er3*0., color='purple', marker='o', ls='None', markersize=mks, markeredgecolor='purple', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 3\cdot 10^{20}$')
	plt.errorbar(nh2, sig2*nh2, xerr=nh2*0., yerr=er2, color='0', marker='o', ls='None', markersize=mks, markeredgecolor='k', markeredgewidth=1, label='Planck data, '+r'$X_{CO} = 2\cdot 10^{20}$')
	plt.errorbar(nhi, r1*nhi, xerr=nhier, yerr=r1er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 19 sightlines without CO and OH detection')
	plt.errorbar(hi, r2*hi, xerr=hier, yerr=r2er, color='r', marker='o', ls='None', markersize=mks, markeredgecolor='r', markeredgewidth=1, label='From 16 low $N_{HI}$ sightlines (no OH detection, but no CO data)')

	plt.title('', fontsize=0)
	plt.ylabel(r'$\mathrm{\mathcal{R}}$', fontsize=fts, fontweight='normal')
	plt.xlabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=fts, fontweight='normal')
	
	plt.tick_params(axis='x', labelsize=20)
	plt.tick_params(axis='y', labelsize=15)
	# plt.yscale('log')
	# plt.xscale('log')
                                         
	

	plt.xlim(0.7, 60.0)
	# plt.ylim(1.,10.)

	plt.tight_layout()
	
	plt.show()


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 19 sources with no CO - l/b/name && 16 src low NHI #
info   = md.read_19src_noco_nooh(fname = '../../oh/result/19src_noCO_noOH.txt')
lownhi = md.read_23rc_lownhi(fname = '../../oh/result/16src_lowNHI.txt')

## cal N(H)
nh_from_radiance(map_file, info, lownhi)