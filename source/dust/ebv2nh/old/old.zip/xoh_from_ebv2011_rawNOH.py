import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md
import copy

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit
from scipy.odr           import *

## Linear fucntion ##
 #
 # params list/float p Parameters
 # params 
 #
 # return 
 #
 # version 03/2017 
 # author Nguyen Van Hiep ##
def lin_fc(p, x):
     m = p
     return m*x

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	# model  = p[0] * x + p[1]
	model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_noh(fname = '../../oh/OH/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret

## Read info of E(B-V) for OH sources only #
 # src | l | b | E(B-V)SFD_online | err | E(B-V)S&F2011 | err
 #
 # params string fname Filename
 # return dict info
 # 
 # version 04/2017
 # Author Van Hiep ##
def read_ebv_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt', sfd98=False):
	cols = ['idx','src','l', 'b', 'ebv','ebv_er', 'ebvsf','ebvsf_er']
	fmt  = ['i',  's',  'f', 'f', 'f',  'f'    , 'f',   'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()

	if(sfd98):
		return dat['ebv'], dat['ebv_er'], dat['src']
	else:
		return dat['ebvsf'], dat['ebvsf_er'], dat['src']

## Cal NH from tau353 #
 #
 # params dict  info        Infor of the sources
 # params dict  noh         Infor of OH sources
 # params Bool  from_file   Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def nh_from_ebv(info, noh):
	## sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	# cf,cf_er = [5.8e21, 0.0]          ## From Bohlin 1978   
 
	cf,cf_er   = [93.04e20, 6.39e20]    ## From S&F2011
	of,of_er   = [0.35e20, 0.16e20]

	# cf,cf_er   = [105.72e20, 3.27e20]    ## From S&F2011
	# of,of_er   = [0., 0.]

	ci, ci_er, ohsc = read_ebv_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt', sfd98=False)

	# OK - Go #
	rnhi    = []
	rnhi_er = []
	ebv     = []
	ebver   = []

	nh      = []
	nher    = []

	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []
	rnh2    = []
	rnh2_er = []
	rcnm    = []
	rcnm_er = []
	for i in range(0, len(src)):
		if (src[i] not in ohsc):
			continue

		# Calculate mean values of EBV353 #
		val = ci[ ohsc.index( src[i] ) ]
		err = ci_er[ ohsc.index( src[i] ) ]

		# print ohsc.index( src[i] ), src[i], val, err

		ebv.append(val)
		ebver.append(err)
	   
		## Calculate the NH from E(B-V) #
		# n_h = val/1.44 # 1e22; (NH = 1.e22*EBV/1.44)
		n_h   = cf*val + of # 1e22
		nh_er = md.uncertainty_of_product(cf, val, cf_er, err)
		nh_er = np.sqrt(nh_er**2 + of_er**2)

		## N(H2) = (NH-NHI)/2 ##
		nh2 = (n_h-nhi[i]*1e20)/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue

		nh.append(n_h)
		nher.append(nh_er)

		nh2_er = 0.5*md.uncertainty_of_diff(nh_er, nhier[i]*1e20)

		## N(H2) ##
		rnh2.append(nh2) ## e20
		rnh2_er.append(nh2_er) ## e20

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] ) ## e14
		roh_er.append( noh[src[i]]['noher'] ) ## e14
		rsrc.append( src[i] )

		# N(HI) ##
		rnhi.append(nhi[i]*1e20)
		rnhi_er.append(nhier[i]*1e20)

		## CNM ##
		rcnm.append(cnm[i]*1e20)
		rcnm_er.append(cnmer[i]*1e20)

		# print src[i], n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	return rnh2, rnh2_er, roh, roh_er, rsrc, nh, nher, rnhi, rnhi_er, rcnm, rcnm_er


## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def noh_vs_nh2(map_file, info, noh):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	nh2, nh2_er, roh, roh_er, rsrc, \
	nh, nher, rnhi, rnhi_er, rcnm, rcnm_er = nh_from_ebv(info, noh)

	## To Plot ##
	xdata = roh
	ydata = nh2

	# Error bar for x-axis and y-axis
	xerr  = roh_er
	yerr  = nh2_er

	########### MPFIT ############
	xdata = 1.0e14*np.array(xdata)
	ydata = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr  = 1.0e14*np.array(xerr)
	yerr  = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	print 'Mean: ', xoh.mean()
	for x in xoh:
		print 2, x*1e8  ## xoh_from_ebv2011.txt


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'lambda_sfd_ebv.fits'  ## E(B-V) from SFD et al. 1998, IRAS ~6'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')
noh      = read_noh(fname = '../../oh/NOH/total_raw_noh67_21src.txt')

print noh

## cal N(H2)
noh_vs_nh2(map_file, info, noh)