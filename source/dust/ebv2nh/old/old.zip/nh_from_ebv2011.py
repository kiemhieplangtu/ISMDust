import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore

## Cal NH from tau353 #
 #
 # params dict  info        Infor of the sources
 # params dict  noh         Infor of OH sources
 # params Bool  from_file   Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_ebv(info):
	## sources
	src   = info['src']
	nhi   = info['nhi']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	# cf,cf_er = [5.8e21, 0.0]          ## From Bohlin 1978   
 
	cf,cf_er   = [93.04e20, 6.39e20]    ## From S&F2011
	of,of_er   = [0.35e20, 0.16e20]

	# cf,cf_er   = [105.72e20, 3.27e20]    ## From S&F2011
	# of,of_er   = [0., 0.]

	Ebv, Ebver, Av, Src = md.read_ebv_av(fname = 'data/ebv_sfd98_sf2011_for_94src.txt', sfd98=False)

	# OK - Go #
	ebv     = []
	ebver   = []

	rnh2    = []
	rnh2_er = []

	rnh     = []
	rnh_er  = []

	rnhi    = []
	rnhi_er = []

	rav     = []
	rav_er  = []

	rsrc    = []

	rcnm    = []
	rcnm_er = []

	xl      = []
	xb      = []
	for i in range(len(src)):
		l = info['l'][i]
		b = info['b'][i]

		# E(B-V) #
		val = Ebv[i]
		err = Ebver[i]

		ebv.append(val)
		ebver.append(err)
	   
		## Calculate the NH from E(B-V) #
		# n_h = val/1.44 # 1e22; (NH = 1.e22*EBV/1.44)
		n_h   = cf*val + of
		nh_er = md.uncertainty_of_product(cf, val, cf_er, err)
		nh_er = np.sqrt(nh_er**2 + of_er**2)

		n_h   = n_h/1e20
		nh_er = nh_er/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2   = (n_h-nhi[i])/2.

		rnh.append(n_h)
		rnh_er.append(nh_er)

		nh2_er = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		string = '{:10s} {:08.4f}   {:08.4f}   {:10.6f}   {:10.6f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}'\
		.format(src[i], l, b, val, err, n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er)
		print string

		## N(H2) ##
		rnh2.append(nh2)
		rnh2_er.append(nh2_er)

		## N(H) ##
		rnh.append(n_h)
		rnh_er.append(nh_er)

		## N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## l,b ##
		xl.append(l)
		xb.append(b)

	# md.write2file('nh_from_rad_94src.txt', Str)
	return src, xl, xb, ebv, ebver, rnh, rnh_er, rnhi, rnhi_er, rnh2, rnh2_er, rcnm, rcnm_er


## N(H) from E(B-V)SF2011 #
 #
 # params dict info   Information of sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_from_ebv(info):
	src   = info['src']  ## 94 src
	nhi   = info['nhi']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	get_nh_from_ebv(info)


##================= MAIN ========================##
## Filename of the map
pth     = os.getenv("HOME")+'/hdata/dust/'
mapFile = pth + 'lambda_sfd_ebv.fits'  ## E(B-V) from SFD et al. 1998, IRAS ~6'
info94  = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')

## cal N(H)
nh_from_ebv(info94)