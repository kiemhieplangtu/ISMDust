import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import operator
import copy

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit
from scipy.odr           import *

## Linear fucntion ##
 #
 # params list/float p Parameters
 # params 
 #
 # return 
 #
 # version 03/2017 
 # author Nguyen Van Hiep ##
def lin_fc(p, x):
     m,b = p
     return m*x + b

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	model  = p[0] * x + p[1]
	# model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Cal. Pearson correlation coefficient ##
 #
 # params list x x-data
 # params list y y-data
 #
 # return float r Pearson correlation coefficient
 #
 # version 04/2017 
 # author Nguyen Van Hiep ##
def pearson_coeff(x, y):
 	n   = len(x)
 	sxy = 0.
 	sx  = 0.
 	sy  = 0.
 	sx2 = 0.
 	sy2 = 0.
 	for i in range(n):
 		sxy = sxy + x[i]*y[i]
 		sx  = sx  + x[i]
 		sy  = sy  + y[i]
 		sx2 = sx2 + x[i]**2
 		sy2 = sy2 + y[i]**2

	t1 = n*sxy
	t2 = sx*sy

	t3 = n*sx2 - sx**2
	t3 = np.sqrt(t3)

	t4 = n*sy2 - sy**2
	t4 = np.sqrt(t4)

	r  = (t1-t2)/t3/t4

	return r

## Cal. uncertainty in the mean #
 #
 # params list lst List of numbers
 # return float ret Uncertainty in the mean
 # 
 # Author Van Hiep ##
def cal_uncertainty_in_mean(lst):
	n    = len(lst)
	mean = sum(lst)/float(n)

	s    = 0
	for i in range(n):
		s = s + (lst[i] - mean)**2

	s = np.sqrt(s)
	return s/n

## Read NHI from 94src #
 #
 # params string fname Filename
 # return dict info of N(HI)
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_nhi_94src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_sponge_prior.txt'):
	cols = ['indx', 'src', 'l', 'b', 'nhi', 'nhi_er', 'thin', 'thin_er', 'cnm', 'cnm_er', 'wnm', 'wnm_er']
	fmt  = ['i',     's',   'f','f',  'f',   'f',     'f',     'f',        'f',   'f',      'f',   'f'   ]
	data = restore(fname, 2, cols, fmt)
	return data.read()

## Read info of 26 no-CO sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict infocd 
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_info_no_co(fname = '../../co12/result/26src_no_co_with_sponge.dat'):
	cols = ['idx','src','l','b','ra_icrs','de_icrs','ra_j','de_j', 'oh', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f','f', 'f',    'f',       's',    's',    'i', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Read info of 23 LOW NHI sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict info
 # 
 # version 12/2016
 # Author Van Hiep ##
def read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt'):
	cols = ['idx','src','l', 'b', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er', 'oh']
	fmt  = ['i',  's',  'f', 'f', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    , 'i']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Get Radiance #
 #
 # params array r_map  Map of Radiance
 # params dict  info   Infor of the sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_radiance(r_map, info):
	# Define constants #
	deg2rad = np.pi/180.

	## sources
	src = info['src']  ## src

	# Define the width of area #
	beam   = 5.            # Beam = 36'
	dbeam  = beam/120.0     # Beam = 36' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(r_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	r    = []
	rer  = []

	rd     = {}
	rd_err = {}

	for i in range(0, len(src)):
		# Find the values of R353 and Err_R353 in small area #
		rd[i] = []

		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (r_map[pix] > -0.000001) : # Some pixels not defined
			rd[i].append(r_map[pix])

		for x in pl.frange(l-offset, l+offset, dd):
			for y in pl.frange(b-offset, b+offset, dd):
				cosb = np.cos(b*deg2rad)
				cosy = np.cos(y*deg2rad)

				if ( ((x-l)**2 + (y-b)**2) <= offset**2 ):
					# hp.projtext(x, y, '.', lonlat=True, coord='G')
					theta = (90.0 - y)*deg2rad
					phi   = x*deg2rad
					pix   = hp.ang2pix(nside, theta, phi, nest=False)

					if (r_map[pix] > -0.000001) :
						rd[i].append(r_map[pix])

		vrd = list(set(rd[i]))
		cnt = len(vrd)

		# Calculate mean values of Radiance-353 #
		val = sum(vrd)/float(cnt)
		err = cal_uncertainty_in_mean(vrd)

		r.append(val)
		rer.append(err)

	return r, rer

## Cal E(B-V), Planck data R1.2 #
 #
 # params array ebv_map  Map of E(B-V)
 # params dict  info     Infor of the sources
 #
 # return list info
 # 
 # version 03/2017
 # Author Van Hiep ##
def cal_ebv(ebv_map, info):
	# Define constants #
	deg2rad = np.pi/180.

	## sources
	src = info['src']  ## src

	# Define the width of area #
	beam   = 5.            # Beam = 36'
	dbeam  = beam/120.0     # Beam = 36' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(ebv_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/15.0

	# OK - Go #
	ebv    = []
	ebver  = []
	nh     = []
	nher   = []

	ci     = {}
	ci_err = {}

	for i in range(0, len(src)):
		# Find the values of ebv353 and Err_ebv353 in small area #
		ci[i]   = []

		l = info['l'][i]
		b = info['b'][i]


		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (ebv_map[pix] > -0.000001) : # Some pixels not defined
			ci[i].append(ebv_map[pix])

		for x in pl.frange(l-offset, l+offset, dd):
			for y in pl.frange(b-offset, b+offset, dd):
				cosb = np.cos(b*deg2rad)
				cosy = np.cos(y*deg2rad)

				if ( ((x-l)**2 + (y-b)**2) <= offset**2 ):
					# hp.projtext(x, y, '.', lonlat=True, coord='G')
					theta = (90.0 - y)*deg2rad
					phi   = x*deg2rad
					pix   = hp.ang2pix(nside, theta, phi, nest=False)

					if (ebv_map[pix] > -0.000001) :
						ci[i].append(ebv_map[pix])

		vci = list(set(ci[i]))
		cnt = len(vci)

		# Calculate mean values of EBV353 #
		val = sum(vci)/float(cnt)
		err = cal_uncertainty_in_mean(vci)

		ebv.append(val)
		ebver.append(err)

	return ebv, ebver

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 23 low-nhi sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def get_gas_column_density(map_file, info, lownhi):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	thin  = info['thin']
	thinr = info['thin_er']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	## 23 lownhi sources
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']
	lwnm   = lownhi['wnm']
	lwnmer = lownhi['wnm_er']
	lcnm   = lownhi['cnm']
	lcnmer = lownhi['cnm_er']

	# Radiance53 map, err_R353 map and resolution #
	r_map      = hp.read_map(map_file, field = 3)
	r353, r_er = get_radiance(r_map, info)

	ci_map     = hp.read_map(map_file, field = 2)
	ci, cier   = cal_ebv(ci_map, info)

	## To Plot ##
	ydata = ci
	xdata = r353

	# Error bar for x-axis and y-axis
	yerr = cier
	xerr = r_er

	xer_mean = np.mean(xerr)
	for i in range(len(xerr)):
		if(xerr[i] == 0.0):
			xerr[i] = xer_mean

	########### MPFIT ############
	xdata = np.array(xdata)   ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	ydata = np.array(ydata)        ## 1e20

	# Error bar for x-axis and y-axis
	xerr  = np.array(xerr)     ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	yerr  = np.array(yerr)          ## 1e20

	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', pearson_coeff(xdata, ydata)

	plt.errorbar(1e8*xdata, ydata, xerr=1e8*xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')

	# plt.title('Correlation between Total HI column densities $N_{HI}$ and \n HI optically thin column densities $N^*_{HI}$ along 94 (Millennium Survey & 21-SPONGE) lines-of-sight', fontsize=30)
	plt.xlabel('$Radiance\ . 10^{11} (Wcm^{-2}sr^{-1})$', fontsize=35)
	plt.ylabel('$E(B-V) (mag)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))

	# plt.text(0.001, 22., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# plt.savefig("test.png",bbox_inches='tight')
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()

	sys.exit()

	## Fit ##
	lguess  = [3.0, 1.0]
	# lguess  = [58.0]

	npar    = len(lguess)
	guessp  = np.array(lguess, dtype='float64')
	plimd   = [[False,False]]*npar
	plims   = [[0.,0.]]*npar
	parbase = {'value': 0., 'fixed': 0, 'parname': '', 'limited': [0, 0], 'limits': [0., 0.]}
	pname   = ['slope','offset']
	pfix    = [False]*npar

	parinfo = []
	for i in range(len(guessp)):
		parinfo.append(copy.deepcopy(parbase))

	for i in range(len(guessp)):
		parinfo[i]['value']   = guessp[i]
		parinfo[i]['fixed']   = pfix[i]
		parinfo[i]['parname'] = pname[i]
		parinfo[i]['limited'] = plimd[i]

	x  = xdata.astype(np.float64)
	y  = ydata.astype(np.float64)
	er = yerr.astype(np.float64)

	fa = {'x':x, 'y':y, 'err':er}
	mp = mpfit(myfunc, guessp, parinfo=parinfo, functkw=fa, quiet=True)

	## ********* Results ********* ##
	print '********* Results *********'
	abp   = mp.params
	abper = mp.perror
	for i in range(len(parinfo)):
		print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	yfit  = a[:, None] * xfit + b[:, None]
	# yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	fit   = abp[0]*x+abp[1]
	# fit   = abp[0]*x

	m  = round(abp[0],4)
	b  = round(abp[1],4)
	ea = round(abper[0],4)
	eb = round(abper[1],4)

	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='MPFIT linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	# plt.title('Correlation between Total HI column densities $N_{HI}$ and \n HI optically thin column densities $N^*_{HI}$ along 94 (Millennium Survey & 21-SPONGE) lines-of-sight', fontsize=30)
	plt.xlabel('$Radiance\ . 10^{11} (Wcm^{-2}sr^{-1})$', fontsize=35)
	plt.ylabel('$N_{HI}/10^{20} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)

	# plt.text(0.001, 22., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R$', color='blue', fontsize=20)
	plt.text(0.02, 22., '$fit = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R + ['+str(b)+'\pm'+str(eb)+']\cdot10^{31}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# plt.savefig("test.png",bbox_inches='tight')
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()
	########### END - MPFIT ############


	########### ODR fit ############
	# Create a model for Orthogonal distance regression (ODR) fitting.
	lin_model = Model(lin_fc)
	# Create a RealData object using our initiated data from above.
	data      = RealData(xdata, ydata, sx=xerr, sy=yerr)
	# Set up ODR with the model and data.
	odr       = ODR(data, lin_model, beta0=lguess)
	# Run the regression.
	out       = odr.run()

	## ********* Results ********* ##
	print '********* ODR Results *********'
	abp   = out.beta
	abper = out.sd_beta
	for i in range(len(lguess)):
		print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	yfit  = a[:, None] * xfit + b[:, None]
	# yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	fit   = abp[0]*x+abp[1]
	# fit   = abp[0]*x

	m  = round(abp[0],4)
	b  = round(abp[1],4)
	ea = round(abper[0],4)
	eb = round(abper[1],4)

	# plt.plot(xdata,ydata, 'ok', ls='None', marker='.', lw=1, label='Factor $f = N_{HI}$/$N^*_{HI}$')
	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.xlabel('$Radiance\ . 10^{11} (Wcm^{-2}sr^{-1})$', fontsize=35)
	plt.ylabel('$N_{HI}/10^{20} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))

	plt.text(0.2, 12., '$fit = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R + ['+str(b)+'\pm'+str(eb)+']\cdot10^{31}$', color='blue', fontsize=20)
	# plt.text(0.001, 12., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R$', color='blue', fontsize=20)
	# plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)
	plt.legend(loc='upper left', fontsize=18)
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()
	########### END - ODR ############


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
info     = read_info_no_co('../../co12/result/26src_no_co_with_sponge.dat')
lownhi   = read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt')
info     = read_nhi_94src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_sponge_prior.txt')

## cal N(H)
get_gas_column_density(map_file, info, lownhi)