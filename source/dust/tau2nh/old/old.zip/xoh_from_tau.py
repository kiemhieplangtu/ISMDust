import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore


## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 # params dict  noh      Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_tau353(tau_map, err_map, info, noh):
	avInf = md.read_av_for_oh_src(fname = '../ebv2nh/data/ebv_sfd98_sf2011_for_oh_src.txt')

	## Infor of sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	ohsc  = []
	for sc in noh:
		if(sc in src):
			ohsc.append(sc)

	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown
	## find Planck Conversion Factor (Dust opacity and Its error) ## 
	planck_cf,pl_fact_err = [6.7783e-27, 3.0459e-28] #6.6e-27, 0.66e-26, lowNHI
	bb,bErr               = [0., 0.]              ## If having intercerpt
	corrEff               = 1.0
	# planck_cf,pl_fact_err = [0.84e-26, 0.3e-26] #6.6e-27, 0.66e-26, lowNHI

	# planck_cf,pl_fact_err = [1.26e-26, 8.92e-28]   ## From tau353_vs_N(HI) fit (26 src without CO & 21 src with low N(HI))
	# of,of_er              = [-8.43e-27, 2.04e-27]

	# Define the width of area #
	beam   = 5.             # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(tau_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	rnhi    = []
	rnhi_er = []
	tau353  = []
	tau_er  = []
	nhfk    = []
	nhfker  = []
	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []
	rcnm    = []
	rcnm_er = []
	rnh     = []
	rnh_er  = []
	rnhi    = []
	rnhi_er = []
	rav     = []
	rav_er  = []
	xl      = []
	xb      = []
	for i in range(len(src)):
		if (src[i] not in ohsc):
			continue

		# if( noh[src[i]]['noh'] > 4.):
		# 	continue

		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau_i   = tau_map[pix]
			t_err_i = err_map[pix]

		# Calculate the N(HI) from Fukui factor #
		nhfk_i = fukui_cf*tau_i
		nhfk_i = nhfk_i/1e20
	   
		# Calculate the NH from Planck factor #
		nh_i   = tau_i/planck_cf
		nh_i   = nh_i/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2    = (nh_i-nhi[i])/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue
		
		# print nh_i, nhi[i]*1e20, nh2
		nhfk.append(nhfk_i)

		# Uncertainties of mean values of N(HI) and N(H) #
		fukui_sd  = (t_err_i*fukui_cf)
		nh_er     = md.nh_uncert_from_proxies(tau_i, t_err_i, planck_cf, pl_fact_err, bb, bErr, corrEff)
		nh_er     = nh_er/1e20

		nh2_er    = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		## N(H2) ##
		rnh2.append(nh2) ## e20
		rnh2_er.append(nh2_er) ## e20

		## N(OH) ##
		roh.append( noh[src[i]]['noh']) ## e14
		roh_er.append( noh[src[i]]['noher']) ## e14
		rsrc.append( src[i] )

		## N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## N(H) ##
		rnh.append(nh_i)
		rnh_er.append(nh_er)

		## l,b ##
		xl.append(l)
		xb.append(b)

		## Av ##
		av    = avInf[src[i]]['av']
		aver  = avInf[src[i]]['aver']
		rav.append(av)
		rav_er.append(aver)

		# print src[i], nh_i, planck_sd, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	# return rnh2, rnh2_er, rnhi, rnhi_er, rnh, rnh_er, roh, roh_er, rav, rav_er, rsrc
	return rnh2, rnh2_er, rnhi, rnhi_er, rnh, rnh_er, roh, roh_er, rav, rav_er, rcnm, rcnm_er, rsrc, xl, xb

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_from_tau353(map_file, info, noh):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	# tau353 map, err_tau353 map and resolution #
	tau_map  = hp.read_map(map_file, field = 0)
	err_map  = hp.read_map(map_file, field = 1)

	nh2, nh2_er, rnhi, rnhi_er, rnh, rnh_er, \
	roh, roh_er, rav, rav_er, rcnm, rcnm_er, rsrc, xl, xb = get_nh_from_tau353(tau_map, err_map, info, noh)

	## To Plot ##
	xdata  = roh
	ydata  = nh2

	# Error bar for x-axis and y-axis
	xerr   = roh_er
	yerr   = nh2_er

	########### MPFIT ############
	xdata  = np.array(xdata)
	ydata  = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr   = np.array(xerr)
	yerr   = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = md.uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	print 'Mean: ', xoh.mean()
	
	for i in range(0, len(xoh)):
		print 1, rsrc[i], xl[i], xb[i], xoh[i], xoh_er[i], nh2[i], nh2_er[i], rnhi[i], rnhi_er[i], rnh[i], rnh_er[i],\
		rcnm[i], rcnm_er[i], roh[i], roh_er[i], rav[i], rav_er[i] ## xoh_from_tau.txt
		       ## src     l,     b      1e-6         1e-6          1e20           1e20            1e20      1e20        1e20          1e20             
        #1e14         1e14        	    mag     mag
        # text = str(2)+'\t'+rsrc[i]+'\t'+str(xl[i])+'\t'+str(xb[i])+'\t'+str(xoh[i]*1e8)+'\t'+str( round(np.sqrt(xoh_er[i]*1e8) ) + '\n'

	plt.errorbar(nh2, xoh, xerr=nh2_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH2', fontsize=30)
	plt.xlabel('$NH2$', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rnhi, xoh, xerr=rnhi_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NHI', fontsize=30)
	plt.xlabel('NHI', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rcnm, xoh, xerr=rcnm_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs CNM', fontsize=30)
	plt.xlabel('CNM', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rnh, xoh, xerr=rnh_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH', fontsize=30)
	plt.xlabel('NH', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rav, xoh, xerr=rav_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs A$_{V}$', fontsize=30)
	plt.xlabel('$A_{V}$ mag', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
# lownhi   = md.read_23rc_lownhi(fname = '../../oh/result/23src_lowNHI.txt')
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = md.read_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
# noh      = md.read_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')

## cal N(H)
nh_from_tau353(map_file, info, noh)