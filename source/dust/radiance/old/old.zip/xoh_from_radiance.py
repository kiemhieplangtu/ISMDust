import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md
import copy

from restore             import restore

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_total_noh(fname = '../../oh/result/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret

## Cal NH from Radiance #
 #
 # params array r_map    Map of Radiance
 # params dict  info     Infor of the sources
 # params dict  noh      Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_radiance(tau_map, tauer_map, r_map, info, noh):
	avInf    = md.read_av_for_oh_src(fname = '../ebv2nh/data/ebv_sfd98_sf2011_for_oh_src.txt')
	aa,aErr  = [4.04604e31, 0.32228e31]   ## From Radiance vs N(HI), 26 src without CO and 21 src with low N(HI)
	bb,bErr  = [0.09269e20, 0.20563e20]
	corrEff  = -0.897768

	## sources
	src   = info['src']
	nhi   = info['nhi']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	ohsc  = []
	for sc in noh:
		if(sc in src):
			ohsc.append(sc)

	# Define constants #
	deg2rad  = np.pi/180.
	fct      = 0.0276   ## Tau and Radiance
	fct_er   = 0.00072

	# Define the width of area #
	beam     = 5.             # Beam = 36'
	dbeam    = beam/120.0     # Beam = 36' -> dbeam = beam/60/2 in degree
	offset   = dbeam          # degree

	nside    = hp.get_nside(r_map)
	res      = hp.nside2resol(nside, arcmin=False)
	dd       = res/deg2rad/10.0

	# OK - Go #
	rd       = []
	rder     = []

	nh       = []
	nher     = []

	roh      = []
	roh_er   = []
	rnh2     = []
	rnh2_er  = []
	rnh      = []
	rnh_er   = []
	rnhi     = []
	rnhi_er  = []
	rav      = []
	rav_er   = []
	rsrc     = []
	rcnm     = []
	rcnm_er  = []
	xl       = []
	xb       = []
	for i in range(0, len(src)):
		if (src[i] not in ohsc):
			continue

		# Find the values of ebv353 and Err_ebv353 in small area #
		ci_i  = []

		l     = info['l'][i]
		b     = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if (r_map[pix] > -0.000001) : # Some pixels not defined
			xtau   = tau_map[pix]
			xtauer = tauer_map[pix]
			val    = r_map[pix]

			d1     = fct_er/fct
			d2     = xtauer/xtau
			dr     = np.sqrt(d1**2 + d2**2)
			err    = val*dr
			err    = xtau*fct*dr

		val = 1e-4 * val  ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
		err = 1e-4 * err  ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	   
		## Calculate the NH from Radiance #
		n_h   = aa*val + bb # 1e22
		nh_er = md.nh_uncert_from_proxies(val, err, aa, aErr, bb, bErr, corrEff)
		
		n_h   = n_h/1e20
		nh_er = nh_er/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2   = (n_h-nhi[i])/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue

		nh2_er = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		## Radiance ##
		rd.append(val)
		rder.append(err)

		## N(H2) ##
		rnh2.append(nh2)
		rnh2_er.append(nh2_er)

		## N(H) ##
		rnh.append(n_h)
		rnh_er.append(nh_er)

		## N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] )
		roh_er.append( noh[src[i]]['noher'] )
		rsrc.append( src[i] )

		## l,b ##
		xl.append(l)
		xb.append(b)

		## Av ##
		av    = avInf[src[i]]['av']
		aver  = avInf[src[i]]['aver']
		rav.append(av)
		rav_er.append(aver)

		# print src[i], n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	## NH vs Radiance ##	
	plt.errorbar(rd, rnh, xerr=rder, yerr=rnh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('N$_{H}$ (from Hiep) vs R', fontsize=30)
	plt.xlabel('Rad', fontsize=35)
	plt.ylabel('$N_{H}$', fontsize=35)
	plt.grid(True)
	# plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	return rnh2, rnh2_er, rnhi, rnhi_er, rnh, rnh_er, roh, roh_er, rav, rav_er, rcnm, rcnm_er, rsrc, xl, xb

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_from_radiance(map_file, info, noh):
	src   = info['src']
	nhi   = info['nhi']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	## Radiance map R1.2 ##
	tau_map                        = hp.read_map(map_file, field = 0)
	tauer_map                      = hp.read_map(map_file, field = 1)
	r_map                          = hp.read_map(map_file, field = 3)
	nh2, nh2_er, rnhi, rnhi_er, \
	rnh, rnh_er, roh, roh_er, \
	rav, rav_er, rcnm, rcnm_er, \
	rsrc, xl, xb                   = get_nh_from_radiance(tau_map, tauer_map, r_map, info, noh)

	# sys.exit()

	print len(nh2)
	print len(nh2_er)
	print len(roh)
	print len(roh_er)

	## To Plot ##
	xdata  = roh
	ydata  = nh2

	# Error bar for x-axis and y-axis
	xerr   = roh_er
	yerr   = nh2_er

	########### MPFIT ############
	xdata  = np.array(xdata)
	ydata  = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr   = np.array(xerr)
	yerr   = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = md.uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	print 'Mean: ', xoh.mean()
	for i in range(0, len(xoh)):
		print 3, rsrc[i], xl[i], xb[i], xoh[i], xoh_er[i], nh2[i], nh2_er[i], rnhi[i], rnhi_er[i], rnh[i], rnh_er[i],\
		rcnm[i], rcnm_er[i], roh[i], roh_er[i], rav[i], rav_er[i] ## xoh_from_radiance.txt
		       ## src     l,     b      1e-6         1e-6          1e20           1e20            1e20      1e20        1e20          1e20             
        #1e14         1e14        	    mag     mag

	## NHI vs NH ##	
	plt.errorbar(rnhi, rnh, xerr=rnhi_er, yerr=rnh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('N$_{H}$ (from Hiep) vs NH', fontsize=30)
	plt.xlabel('$NH$ mag', fontsize=35)
	plt.ylabel('$N_{HI}$', fontsize=35)
	plt.grid(True)
	# plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	print md.cov_xy(np.array(rnh)*1e20, np.array(rnhi)*1e20 )
	sys.exit()

	plt.errorbar(nh2, xoh, xerr=nh2_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH2', fontsize=30)
	plt.xlabel('$NH2$ mag', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rnhi, xoh, xerr=rnhi_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NHI', fontsize=30)
	plt.xlabel('NHI', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()



	plt.errorbar(rnh, xoh, xerr=rnh_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH', fontsize=30)
	plt.xlabel('NH', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rav, xoh, xerr=rav_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs A$_{V}$', fontsize=30)
	plt.xlabel('$A_{V}$ mag', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()



##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from Planck r.12, IRAS ~5'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
# info     = read_nhi_94src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_sponge_prior.txt')
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = md.read_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
# noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')

## cal N(H)
nh_from_radiance(map_file, info, noh)