import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore


## Cal NH from Radiance #
 #
 # params array tauMap    Map of Tau353
 # params array tauerMap  Map of Tau353_error
 # params array rMap      Map of Radiance
 # params dict  info      Information of 94 sources
 # params dict  avInf     Information of E(B-V) and Av for 21 OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_tau(tauMap, tauerMap, info, avInf):
	## Infor of sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown
	## find Planck Conversion Factor (Dust opacity and Its error) ## 
	planck_cf,pl_fact_err = [6.778e-27, 3.046e-28] #6.6e-27, 0.66e-26, lowNHI
	of,of_er              = [0., 0.]              ## If having intercerpt
	# planck_cf,pl_fact_err = [0.84e-26, 0.3e-26] #6.6e-27, 0.66e-26, lowNHI

	# planck_cf,pl_fact_err = [1.26e-26, 8.92e-28]   ## From tau353_vs_N(HI) fit (26 src without CO & 21 src with low N(HI))
	# of,of_er              = [-8.43e-27, 2.04e-27]

	nside  = hp.get_nside(tauMap)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	tau353  = []
	tau_er  = []

	rnh2    = []
	rnh2_er = []

	rnh     = []
	rnh_er  = []

	rnhi    = []
	rnhi_er = []

	rav     = []
	rav_er  = []

	rsrc    = []

	rcnm    = []
	rcnm_er = []

	xl      = []
	xb      = []
	for i in range(len(src)):
		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (tauerMap[pix] >= 6.9e-11) and (tauerMap[pix] <= 0.00081) and (tauMap[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau_i   = tauMap[pix]
			t_err_i = tauerMap[pix]

		tau353.append(tau_i)
		tau_er.append(t_err_i)

		# Calculate the N(HI) from Fukui factor #
		nhfk_i = fukui_cf*tau_i
		nhfk_i = nhfk_i/1e20	
	   
		# Calculate the NH from Planck factor #
		nh_i   = tau_i/planck_cf
		nh_i   = nh_i/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2    = (nh_i-nhi[i])/2.

		# Uncertainties of mean values of N(HI) and N(H) #
		fukui_sd  = (t_err_i*fukui_cf)
		nh_er     = md.uncertainty_of_ratio(tau_i, planck_cf, t_err_i, pl_fact_err)
		nh_er     = np.sqrt(nh_er**2 + of_er**2)
		nh_er     = nh_er/1e20

		nh2_er    = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		## N(H2) ##
		rnh2.append(nh2) ## e20
		rnh2_er.append(nh2_er) ## e20

		rsrc.append( src[i] )

		## N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## N(H) ##
		rnh.append(nh_i)
		rnh_er.append(nh_er)

		## l,b ##
		xl.append(l)
		xb.append(b)

		string = '{:10s} {:08.4f}   {:08.4f}   {:10.6f}   {:10.6f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}'\
		.format(src[i], l, b, tau_i*1e6, t_err_i*1e6, nh_i, nh_er, nhi[i], nhier[i], nh2, nh2_er)
		print string

	return rsrc, xl, xb, tau353, tau_er, rnh, rnh_er, rnhi, rnhi_er, rnh2, rnh2_er, rcnm, rcnm_er

## Get tau353 values and err_tau353 values #
 #
 # params str  mapFile File of maps
 # params dict info94   Information of 94 sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 08/2017 
 # Author Van Hiep ##	
def nh_from_tau(mapFile, info94, avInf):
	# tau353 map, err_tau353 map and resolution #
	tauMap    = hp.read_map(mapFile, field=0)
	tauerMap  = hp.read_map(mapFile, field=1)

	rsrc, xl, xb, tau353, tau_er, rnh, rnh_er, \
	rnhi, rnhi_er, rnh2, rnh2_er, rcnm, rcnm_er = get_nh_from_tau(tauMap, tauerMap, info94, avInf)

	print len(rnh2)
	print len(rnh2_er)

	## NH vs Radiance ##	
	plt.errorbar(tau353, rnh, xerr=tau_er, yerr=rnh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('N$_{H}$ (from Hiep) vs R', fontsize=30)
	plt.xlabel('Tau353', fontsize=35)
	plt.ylabel('$N_{H}$', fontsize=35)
	plt.grid(True)
	# plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

##================= MAIN ========================##
## Filename of the map
pth     = os.getenv("HOME")+'/hdata/dust/'
mapFile = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from Planck r.12, IRAS ~5'

avInf   = md.read_av_for_oh_src(fname = '../ebv2nh/data/ebv_sfd98_sf2011_for_oh_src.txt')
info94  = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')

## cal N(H)
nh_from_tau(mapFile, info94, avInf)