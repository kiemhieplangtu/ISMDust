import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md
import copy

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit
from scipy.odr           import *

## Linear fucntion ##
 #
 # params list/float p Parameters
 # params 
 #
 # return 
 #
 # version 03/2017 
 # author Nguyen Van Hiep ##
def lin_fc(p, x):
     m = p
     return m*x

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	# model  = p[0] * x + p[1]
	model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_noh(fname = '../../oh/result/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret


## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 # params dict  noh      Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def nh_from_tau353(tau_map, err_map, info, noh):
	## Infor of sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	ohsc  = []
	for sc in noh:
		if(sc in src):
			ohsc.append(sc)

	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown
	## find Planck Conversion Factor (Dust opacity and Its error) ## 
	planck_cf,pl_fact_err = [7.065e-27, 2.71e-28] #6.6e-27, 0.66e-26, lowNHI
	of,of_er              = [0., 0.]              ## If having intercerpt
	# planck_cf,pl_fact_err = [0.84e-26, 0.3e-26] #6.6e-27, 0.66e-26, lowNHI

	# planck_cf,pl_fact_err = [1.26e-26, 8.92e-28]   ## From tau353_vs_N(HI) fit (26 src without CO & 21 src with low N(HI))
	# of,of_er              = [-8.43e-27, 2.04e-27]

	# Define the width of area #
	beam   = 5.             # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(tau_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	rnhi    = []
	rnhi_er = []
	tau353  = []
	tau_er  = []
	nh      = []
	nher    = []
	nhfk    = []
	nhfker  = []
	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []
	rcnm    = []
	rcnm_er = []
	for i in range(len(src)):
		if (src[i] not in ohsc):
			continue

		# if( noh[src[i]]['noh'] > 4.):
		# 	continue

		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau_i   = tau_map[pix]
			t_err_i = err_map[pix]

		# Calculate the N(HI) from Fukui factor #
		nhfk_i = fukui_cf*tau_i	
	   
		# Calculate the NH from Planck factor #
		nh_i   = tau_i/planck_cf

		## N(H2) = (NH-NHI)/2 ##
		nh2    = (nh_i-nhi[i]*1e20)/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue
		
		# print nh_i, nhi[i]*1e20, nh2
		nhfk.append(nhfk_i)
		nh.append(nh_i)

		# Uncertainties of mean values of N(HI) and N(H) #
		fukui_sd  = (t_err_i*fukui_cf)
		nh_er     = md.uncertainty_of_ratio(tau_i, planck_cf, t_err_i, pl_fact_err)
		nh_er     = np.sqrt(nh_er**2 + of_er**2)	

		nh2_er    = 0.5*md.uncertainty_of_diff(nh_er, nhier[i]*1e20)
		nher.append(nh_er)

		## N(H2) ##
		rnh2.append(nh2) ## e20
		rnh2_er.append(nh2_er) ## e20

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] * 1e14) ## e14
		roh_er.append( noh[src[i]]['noher'] * 1e14) ## e14
		rsrc.append( src[i] )

		## N(HI) ##
		rnhi.append(nhi[i]*1e20)
		rnhi_er.append(nhier[i]*1e20)

		## CNM ##
		rcnm.append(cnm[i]*1e20)
		rcnm_er.append(cnmer[i]*1e20)

		# print src[i], nh_i, planck_sd, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	return rnh2, rnh2_er, roh, roh_er, rsrc, nh, nher, rnhi, rnhi_er, rcnm, rcnm_er

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def noh_vs_nh2(map_file, info, noh):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	# tau353 map, err_tau353 map and resolution #
	tau_map  = hp.read_map(map_file, field = 0)
	err_map  = hp.read_map(map_file, field = 1)

	nh2, nh2_er, roh, roh_er, rsrc, \
	nh, nher, rnhi, rnhi_er, rcnm, rcnm_er = nh_from_tau353(tau_map, err_map, info, noh)

	# print len(nh2)
	# print len(nh2_er)
	# print len(roh)
	# print len(roh_er)
	# print len(rnhi)
	# print len(nh)

	## To Plot ##
	xdata  = roh
	ydata  = nh2

	# Error bar for x-axis and y-axis
	xerr   = roh_er
	yerr   = nh2_er

	########### MPFIT ############
	xdata  = np.array(xdata)
	ydata  = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr   = np.array(xerr)
	yerr   = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = md.uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	print 'Mean: ', xoh.mean()
	for x in xoh:
		print 1, x*1e8  ## xoh_from_tau.txt

	xmin   = xoh.min()
	xmax   = xoh.max()
	plt.hist(xoh, alpha=0.5, label='', color='b', ls='-',  histtype='stepfilled', stacked=False, fill=True, range=(xmin,xmax), bins=12, lw=3)

	plt.title(r'X(OH), N(H) from $\tau_{353}$', fontsize=22)
	plt.ylabel('Number', fontsize=22,fontweight='bold')
	plt.xlabel('$X_{OH} = N(OH)/N(H_{2})$', fontsize=22, fontweight='bold')

	plt.tick_params(axis='x', labelsize=22, pad=8)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=9)
	plt.tick_params(which='minor', length=4)
	# plt.legend(loc='upper right', fontsize=22)
	plt.grid(False)

	plt.text(0.05, 15.0, 'Far from 1.0 are l-o-s with very low N(HI) (<3.0e20)', color='blue', fontsize=20)

	plt.tight_layout()
	plt.show()

	##### X(OH) vs N(HI) #####
	plt.errorbar(rnhi, xoh, xerr=rnhi_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$X_{OH}\ vs\ N_{HI}$')

	plt.title('X$_{OH}$ vs N$_{HI}$', fontsize=30)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.xlabel('$N_{HI} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# plt.savefig("test.png",bbox_inches='tight')
	for i in range(len(rsrc)):
		plt.annotate('('+str(rsrc[i])+')', xy=(rnhi[i], xoh[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )
	plt.show()

	##### X(OH) vs N(H) #####
	plt.errorbar(nh, xoh, xerr=nher, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$X_{OH}\ vs\ N_{H}$')

	plt.title('X$_{OH}$ vs N$_{H}$', fontsize=30)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.xlabel('$N_{H} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)

	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(rsrc)):
		plt.annotate('('+str(rsrc[i])+')', xy=(nh[i], xoh[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )

	plt.show()

	##### X(OH) vs N(H2) #####
	plt.errorbar(ydata, xoh, xerr=yerr, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$X_{OH}\ vs\ N_{H_{2}}$')

	plt.title('X$_{OH}$ vs N$_{H_{2}}$', fontsize=30)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.xlabel('$N_{H_{2}} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)

	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(rsrc)):
		plt.annotate('('+str(rsrc[i])+')', xy=(ydata[i], xoh[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )
	plt.show()

	##### X(OH) vs N(CNM) #####
	plt.errorbar(rcnm, xoh, xerr=rcnm_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$X_{OH}\ vs\ N_{H_{2}}$')

	plt.title('X$_{OH}$ vs N$_{CNM}$', fontsize=30)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.xlabel('$N_{CNM} (cm^{-2}$)', fontsize=35)
	# plt.xlim(0.0, 2.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))
	plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)

	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(rsrc)):
		plt.annotate('('+str(rsrc[i])+')', xy=(rcnm[i], xoh[i]), xycoords='data',
		            xytext=(-50.,30.), textcoords='offset points',
		            arrowprops=dict(arrowstyle="->"),fontsize=12,
		            )
	plt.show()


	sys.exit()

	## Fit ##
	lguess  = [ 0.66e-7, 0.66e-8]
	lguess  = [ 1.e7]

	npar    = len(lguess)
	guessp  = np.array(lguess, dtype='float64')
	plimd   = [[False,False]]*npar
	plims   = [[0.,0.]]*npar
	parbase = {'value': 0., 'fixed': 0, 'parname': '', 'limited': [0, 0], 'limits': [0., 0.]}
	pname   = ['slope','offset']
	pfix    = [False]*npar

	parinfo = []
	for i in range(len(guessp)):
		parinfo.append(copy.deepcopy(parbase))

	for i in range(len(guessp)):
		parinfo[i]['value']   = guessp[i]
		parinfo[i]['fixed']   = pfix[i]
		parinfo[i]['parname'] = pname[i]
		parinfo[i]['limited'] = plimd[i]

	x  = xdata.astype(np.float64)
	y  = ydata.astype(np.float64)
	er = yerr.astype(np.float64)

	# fa = {'x':x, 'y':y, 'err':er}
	# mp = mpfit(myfunc, guessp, parinfo=parinfo, functkw=fa, quiet=True)

	# ## ********* Results ********* ##
	# print '********* Results *********'
	# abp   = mp.params
	# abper = mp.perror
	# for i in range(len(parinfo)):
	# 	print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	# ## Plot ##
	# a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# # b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	# xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# # yfit  = a[:, None] * xfit + b[:, None]
	# yfit  = a[:, None] * xfit
	# mu    = yfit.mean(0)
	# sig   = 1.0*yfit.std(0)
	# # fit   = abp[0]*x+abp[1]
	# fit   = abp[0]*x

	# m  = round(abp[0],10)
	# # b  = round(abp[1],10)
	# ea = round(abper[0],10)
	# # eb = round(abper[1],10)

	# plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label=r'$N_{H_{2}}\ vs\ N_{OH}$')
	# plt.plot(xfit, mu, '-b', mew=2, linewidth=4, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='MPFIT linear fit')
	# plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	# plt.title('N$_{H_{2}}$ vs N$_{OH}$', fontsize=30)
	# plt.ylabel('$N_{H_{2}}$', fontsize=35)
	# plt.xlabel('$N_{OH} (cm^{-2}$)', fontsize=35)
	# # plt.xlim(0.0, 2.0)
	# # plt.ylim(-1.0, 6.0)
	# plt.grid(True)
	# plt.tick_params(axis='x', labelsize=18)
	# plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	# plt.text(0.0,1.5e22, '$Conversion factor: \sigma_{353} = [0.926 \pm 0.0332]\cdot 10^{-26}$', color='blue', fontsize=20)
	# # plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	# plt.text(0.0,1e22, '$Fit: y = ['+str(m/1e7)+'\pm'+str(ea/1e7) +']\cdot 10^{7} \cdot N_{OH}$', color='blue', fontsize=20)
	# plt.legend(loc='upper left', fontsize=18)
	# # plt.savefig("test.png",bbox_inches='tight')
	# for i in range(len(rsrc)):
	# 	# if(oh[i] > 0):
	# 	# plt.annotate('('+str(rsrc[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	plt.annotate('('+str(rsrc[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	#             xytext=(-50.,30.), textcoords='offset points',
	#             arrowprops=dict(arrowstyle="->"),fontsize=12,
	#             )
	# plt.show()
	# ########### END - MPFIT ############

	########### ODR fit ############
	# Create a model for Orthogonal distance regression (ODR) fitting.
	lin_model = Model(lin_fc)
	# Create a RealData object using our initiated data from above.
	data      = RealData(xdata, ydata, sx=xerr, sy=yerr)
	# Set up ODR with the model and data.
	odr       = ODR(data, lin_model, beta0=lguess)
	# Run the regression.
	out       = odr.run()

	## ********* Results ********* ##
	print '********* ODR Results *********'
	abp   = out.beta
	abper = out.sd_beta
	for i in range(1):
		print "%s = %03.8f +/- %03.8f" % ('slope',abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m  = round(abp[0],10)
	# b  = round(abp[1],10)
	ea = round(abper[0],10)
	# eb = round(abper[1],10)

	# plt.plot(xdata,ydata, 'ok', ls='None', marker='.', lw=1, label='Factor $f = N_{HI}$/$N^*_{HI}$')
	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.title('N$_{H_{2}}$ vs N$_{OH}$', fontsize=30)
	plt.ylabel('$N_{H_{2}}$', fontsize=35)
	plt.xlabel('$N_{OH} (cm^{-2}$)', fontsize=35)
	# plt.xlim(-1.0, 4.0)

	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	plt.text(0.0,1.5e22, '$Conversion factor: \sigma_{353} = [0.926 \pm 0.0332]\cdot 10^{-26}$', color='blue', fontsize=20)
	# plt.text(0.0,2.5e22, '$Conversion factor: \sigma_{353} = [0.84 \pm 0.3]\cdot 10^{-26}$', color='blue', fontsize=20)
	plt.text(0.0,1e22, '$Fit: y = ['+str(m/1e7)+'\pm'+str(ea/1e7) +']\cdot 10^{7} \cdot N_{OH}$', color='blue', fontsize=20)
	plt.legend(loc='upper left', fontsize=18)
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()
	########### END - ODR ############


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
# lownhi   = md.read_23rc_lownhi(fname = '../../oh/result/23src_lowNHI.txt')
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = read_noh(fname = '../../oh/result/total_noh65_21src.txt')
# noh    = read_noh(fname = '../../oh/result/total_noh67_21src.txt')

print noh

## cal N(H2)
noh_vs_nh2(map_file, info, noh)