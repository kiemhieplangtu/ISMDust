import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import matplotlib        as mpl
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore

## Cal NH from tau353 #
 #
 # params dict  info        Infor of the sources
 # params dict  noh         Infor of OH sources
 # params Bool  from_file   Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_ebv(info):
	## sources
	src   = info['src']
	nhi   = info['nhi']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	# cf,cf_er = [5.8e21, 0.0]          ## From Bohlin 1978   
 
	cf,cf_er   = [93.0365e20, 6.38817e20]    ## From S&F2011
	of,of_er   = [0.354115e20, 0.16128e20]

	# cf,cf_er   = [105.72e20, 3.27e20]    ## From S&F2011
	# of,of_er   = [0., 0.]

	Ebv, Ebver, Av, Src = md.read_ebv_av(fname = 'data/ebv_sfd98_sf2011_for_35src_HI_only.txt', sfd98=False)

	# OK - Go #
	ebv     = []
	ebver   = []

	rnh2    = []
	rnh2_er = []

	rnh     = []
	rnh_er  = []

	rnhi    = []
	rnhi_er = []

	rav     = []
	rav_er  = []

	rsrc    = []

	rcnm    = []
	rcnm_er = []

	xl      = []
	xb      = []
	for i in range(len(src)):
		l = info['l'][i]
		b = info['b'][i]

		# E(B-V) #
		val = Ebv[i]
		err = Ebver[i]

		ebv.append(val)
		ebver.append(err)
	   
		## Calculate the NH from E(B-V) #
		# n_h = val/1.44 # 1e22; (NH = 1.e22*EBV/1.44)
		n_h   = cf*val + of
		nh_er = md.uncertainty_of_product(cf, val, cf_er, err)
		nh_er = np.sqrt(nh_er**2 + of_er**2)

		n_h   = n_h/1e20
		nh_er = nh_er/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2   = (n_h-nhi[i])/2.

		nh2_er = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		string = '{:10s} {:08.4f}   {:08.4f}   {:10.6f}   {:10.6f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}   {:08.4f}'\
		.format(src[i], l, b, val, err, n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er)
		print string

		## N(H2) ##
		rnh2.append(nh2)
		rnh2_er.append(nh2_er)

		## N(H) ##
		rnh.append(n_h)
		rnh_er.append(nh_er)

		## N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## l,b ##
		xl.append(l)
		xb.append(b)

	# md.write2file('nh_from_rad_94src.txt', Str)
	return src, xl, xb, ebv, ebver, rnh, rnh_er, rnhi, rnhi_er, rnh2, rnh2_er, rcnm, rcnm_er


## N(H) from E(B-V)SF2011 #
 #
 # params dict info   Information of sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_from_ebv(info):
	src, xl, xb, ebv, ebver, rnh, rnh_er, rnhi, rnhi_er, rnh2, rnh2_er, rcnm, rcnm_er = get_nh_from_ebv(info)

	print len(rnh)
	print len(rnh_er)
	print len(rnhi)
	print len(rnhi_er)

	# NH vs EBV ##
	mpl.rcParams['axes.linewidth'] = 1.5
	fig          = plt.figure(figsize=(10,5))
	ax           = fig.add_subplot(111); #ax.set_rasterized(True)                                 
	major_xticks = np.arange(0., 0.5, 0.1)
	minor_xticks = np.arange(0., 0.5, 0.05)
	major_yticks = np.arange(0., 80., 10.)                                              
	minor_yticks = np.arange(0., 80., 5.0)

	plt.errorbar(ebv, rnh, xerr=ebver, yerr=rnh_er, color='r', marker='o', ls='None', markersize=6, markeredgecolor='b', markeredgewidth=1, label='fit')
	plt.errorbar(ebv, rnhi, xerr=ebver, yerr=rnhi_er, color='b', marker='^', ls='None', markersize=6, markeredgecolor='b', markeredgewidth=1, label='data')

	plt.title('', fontsize=0)
	plt.xlabel(r'$\mathrm{E(B-V) [mag]}$', fontsize=20)
	plt.ylabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=20)
	
	plt.tick_params(axis='y', labelsize=18)
	plt.tick_params(axis='x', labelsize=18)
	# plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))	

	ax.set_xticks(major_xticks)                                                       
	ax.set_xticks(minor_xticks, minor=True)                                           
	ax.set_yticks(major_yticks)                                                       
	ax.set_yticks(minor_yticks, minor=True)
	plt.tick_params(axis='x', labelsize=16, pad=5)
	plt.tick_params(axis='y', labelsize=16)
	plt.tick_params(which='both', width=1.5)
	plt.tick_params(which='major', length=9)
	plt.tick_params(which='minor', length=4)

	plt.xlim(0.008, 0.42)
	plt.ylim(0.8, 35.0)
	plt.yscale('log')
	plt.xscale('log')

	plt.tight_layout()
	# plt.legend(loc='upper left', fontsize=18)
	plt.savefig('xxx.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	plt.show()


##================= MAIN ========================##
# Info of 19 sources with noCO, noOH and 23 src low NHI- l/b/name && #
info35  = md.read_19src_noco_nooh(fname = '../../oh/result/35src_HI_only.txt')

## cal N(H)
nh_from_ebv(info35)