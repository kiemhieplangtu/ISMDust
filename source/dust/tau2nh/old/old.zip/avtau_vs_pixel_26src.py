import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import pylab             as pl
import operator
import matplotlib.cm     as cm

from restore             import restore
from masks               import masks

## Read info of 26 no-CO sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict infocd 
 # 
 # version 1/2017
 # Author Van Hiep ##
def read_info_no_co(fname = '../../co12/result/26src_no_co_with_sponge.dat'):
	cols = ['idx','src','l','b','ra_icrs','de_icrs','ra_j','de_j', 'oh', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f','f', 'f',    'f',       's',    's',    'i', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Read info of 23 LOW NHI sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict info
 # 
 # version 12/2016
 # Author Van Hiep ##
def read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt'):
	cols = ['idx','src','l', 'b', 'nhi','nhi_er','thin','thin_er', 'cnm','cnm_er','wnm','wnm_er']
	fmt  = ['i',  's',  'f', 'f', 'f',   'f',     'f',    'f'    , 'f',   'f',     'f',  'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	return dat

## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 #
 # return list info
 # 
 # version 12/2016
 # Author Van Hiep ##
def nh_from_tau353(tau_map, err_map, info):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']

	# Define constants #
	deg2rad = np.pi/180.

	# Define the width of area #
	beam   = 5.             # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(tau_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	tau353 = []
	ptau   = []
	pterr  = []

	tau    = {}
	t_err  = {}
	diff   = np.empty([26], dtype=float)

	for i in range(len(src)):
		# Find the values of Tau353 and Err_tau353 in small area #
		tau[i]   = []
		t_err[i] = []

		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau[i].append(tau_map[pix])
			ptau.append(tau_map[pix])
			t_err[i].append(err_map[pix])

		for x in pl.frange(l-offset, l+offset, dd):
			for y in pl.frange(b-offset, b+offset, dd):
				cosb = np.cos(b*deg2rad)
				cosy = np.cos(y*deg2rad)

				if ( ((x-l)**2 + (y-b)**2) <= offset**2 ):
					# hp.projplot(x, y, 'kx', lonlat=True, coord='G')
					theta = (90.0 - y)*deg2rad
					phi   = x*deg2rad
					pix   = hp.ang2pix(nside, theta, phi, nest=False)

					if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
						tau[i].append(tau_map[pix])
						t_err[i].append(err_map[pix])

		temp_tau = list(set(tau[i]))
		t_err[i] = list(set(t_err[i]))

		cnt_tau = len(temp_tau)
		npix    = len(t_err[i])

		if (cnt_tau != npix) :
			tmp_tau = []
			for k in range(npix):
				tmp_tau.append(tau[i][k])

			tau[i] = tmp_tau
		else:
			tau[i] = list(set(tau[i]))

		# Calculate mean values of tau353 #
		tau_i = sum(tau[i])/float(npix)
		tau353.append(sum(tau[i])/float(npix))

		diff[i] = np.abs(tau_i - tau_map[pix])/tau_map[pix]
		print tau_i, tau_map[pix], diff[i]

	print 'Mean diff: ', np.mean(diff)

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 23 low-nhi sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def get_gas_column_density(map_file, info, lownhi):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	thin  = info['thin']
	thinr = info['thin_er']
	oh    = info['oh']
	nhier = info['nhi_er']

	## 23 lownhi sources
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']

	# tau353 map, err_tau353 map and resolution #
	tau_map = hp.read_map(map_file, field = 0)
	err_map = hp.read_map(map_file, field = 1)
	nh_from_tau353(tau_map, err_map, info)
	nh_from_tau353(tau_map, err_map, lownhi)

##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
info   = read_info_no_co('../../co12/result/26src_no_co_with_sponge.dat')
lownhi = read_lownhi_23src(fname = '../../hi/result/lownhi_thin_cnm_wnm.txt')

## cal N(H)
get_gas_column_density(map_file, info, lownhi)