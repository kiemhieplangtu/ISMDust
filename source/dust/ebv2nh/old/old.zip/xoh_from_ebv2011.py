import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_noh(fname = '../../oh/OH/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret

## Read info of E(B-V) for OH sources only #
 # src | l | b | E(B-V)SFD_online | err | E(B-V)S&F2011 | err
 #
 # params string fname Filename
 # return dict info
 # 
 # version 04/2017
 # Author Van Hiep ##
def read_ebv_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt', sfd98=False):
	cols = ['idx','src','l', 'b', 'ebv','ebv_er', 'ebvsf','ebvsf_er']
	fmt  = ['i',  's',  'f', 'f', 'f',  'f'    , 'f',   'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()

	if(sfd98):
		return dat['ebv'], dat['ebv_er'], dat['src']
	else:
		return dat['ebvsf'], dat['ebvsf_er'], dat['src']

## Cal NH from tau353 #
 #
 # params dict  info        Infor of the sources
 # params dict  noh         Infor of OH sources
 # params Bool  from_file   Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def get_nh_from_ebv(info, noh):
	avInf = md.read_av_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt')

	## sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	# a,aErr = [5.8e21, 0.0]          ## From Bohlin 1978   
 
	aa,aErr  = [93.0365e20, 6.3882e20]    ## From S&F2011
	bb,bErr  = [0.35412e20, 0.16128e20]

	corrEff  = -0.888571

	# a,aErr   = [105.72e20, 3.27e20]    ## From S&F2011
	# b,bErr   = [0., 0.]

	ci, ci_er, ohsc = read_ebv_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt', sfd98=False)

	# OK - Go #
	rnhi    = []
	rnhi_er = []
	ebv     = []
	ebver   = []

	nh      = []
	nher    = []

	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []
	rnh2    = []
	rnh2_er = []
	rcnm    = []
	rnh     = []
	rnh_er  = []
	rnhi    = []
	rnhi_er = []
	rav     = []
	rav_er  = []	
	rcnm_er = []
	xl      = []
	xb      = []
	for i in range(0, len(src)):
		if (src[i] not in ohsc):
			continue

		l = info['l'][i]
		b = info['b'][i]

		# Calculate mean values of EBV353 #
		val = ci[ ohsc.index( src[i] ) ]
		err = ci_er[ ohsc.index( src[i] ) ]

		# print ohsc.index( src[i] ), src[i], val, err

		ebv.append(val)
		ebver.append(err)
	   
		## Calculate the NH from E(B-V) #
		# n_h = val/1.44 # 1e22; (NH = 1.e22*EBV/1.44)
		n_h   = aa*val + bb # 1e22
		nh_er = md.nh_uncert_from_proxies(val, err, aa, aErr, bb, bErr, corrEff)

		n_h   = n_h/1e20
		nh_er = nh_er/1e20

		## N(H2) = (NH-NHI)/2 ##
		nh2   = (n_h-nhi[i])/2.

		# 3sources with NHI > NH
		if(nh2 < 0.):
			continue

		rnh.append(n_h)
		rnh_er.append(nh_er)

		nh2_er = 0.5*md.uncertainty_of_diff(nh_er, nhier[i])

		## N(H2) ##
		rnh2.append(nh2)       ## e20
		rnh2_er.append(nh2_er) ## e20

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] )      ## e14
		roh_er.append( noh[src[i]]['noher'] ) ## e14
		rsrc.append( src[i] )

		# N(HI) ##
		rnhi.append(nhi[i])
		rnhi_er.append(nhier[i])

		## CNM ##
		rcnm.append(cnm[i])
		rcnm_er.append(cnmer[i])

		## l,b ##
		xl.append(l)
		xb.append(b)

		## Av ##
		av    = avInf[src[i]]['av']
		aver  = avInf[src[i]]['aver']
		rav.append(av)
		rav_er.append(aver)

		# print src[i], n_h, nh_er, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	# return rnh2, rnh2_er, roh, roh_er, rsrc, nh, nher, rnhi, rnhi_er, rcnm, rcnm_er
	return rnh2, rnh2_er, rnhi, rnhi_er, rnh, rnh_er, roh, roh_er, rav, rav_er, rcnm, rcnm_er, rsrc, xl, xb


## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def nh_from_ebv(map_file, info, noh):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	nh2, nh2_er, rnhi, rnhi_er, rnh, rnh_er, \
	roh, roh_er, rav, rav_er, rcnm, rcnm_er, rsrc, xl, xb = get_nh_from_ebv(info, noh)

	## To Plot ##
	xdata = roh
	ydata = nh2

	# Error bar for x-axis and y-axis
	xerr  = roh_er
	yerr  = nh2_er

	########### MPFIT ############
	xdata = np.array(xdata)
	ydata = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr  = np.array(xerr)
	yerr  = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = md.uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	print xoh, xoh_er
	print 'Mean: ', xoh.mean()

	for i in range(0, len(xoh)):
		print 2, rsrc[i], xl[i], xb[i], xoh[i], xoh_er[i], nh2[i], nh2_er[i], rnhi[i], rnhi_er[i], rnh[i], rnh_er[i],\
		rcnm[i], rcnm_er[i], roh[i], roh_er[i], rav[i], rav_er[i] ## xoh_from_ebv2011.txt
		       ## src     l,     b      1e-6         1e-6          1e20           1e20            1e20      1e20        1e20          1e20             
        #1e14         1e14        	    mag     mag

	
	## NHI vs NH ##	
	plt.errorbar(rnhi, rnh, xerr=rnhi_er, yerr=rnh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('N$_{H}$ (from Hiep) vs NH', fontsize=30)
	plt.xlabel('$NH$ mag', fontsize=35)
	plt.ylabel('$N_{HI}$', fontsize=35)
	plt.grid(True)
	# plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	# print md.cov_xy(np.array(rnh)*1e20, np.array(rnhi)*1e20 )
	sys.exit()
	
	plt.errorbar(nh2, xoh, xerr=nh2_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH2', fontsize=30)
	plt.xlabel('$NH2$ mag', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rnhi, xoh, xerr=rnhi_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NHI', fontsize=30)
	plt.xlabel('NHI', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()



	plt.errorbar(rnh, xoh, xerr=rnh_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs NH', fontsize=30)
	plt.xlabel('NH', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

	plt.errorbar(rav, xoh, xerr=rav_er, yerr=xoh_er, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('X$_{OH}$ (from Hiep) vs A$_{V}$', fontsize=30)
	plt.xlabel('$A_{V}$ mag', fontsize=35)
	plt.ylabel('$X_{OH}$', fontsize=35)
	plt.grid(True)
	plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'lambda_sfd_ebv.fits'  ## E(B-V) from SFD et al. 1998, IRAS ~6'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
# noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')

## cal N(H)
nh_from_ebv(map_file, info, noh)