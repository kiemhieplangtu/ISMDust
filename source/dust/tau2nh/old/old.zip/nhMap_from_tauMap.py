import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore

## Cal NH from Radiance #
 #
 # params array tauMap    Map of Tau353
 # params array tauerMap  Map of Tau353_error
 # params array rMap      Map of Radiance
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def getNhMapFomRadianceMap(tauMap, tauerMap, rMap):
	aa,aErr  = [4.04604e31, 0.32228e31]   ## From Radiance vs N(HI), 26 src without CO and 21 src with low N(HI)
	bb,bErr  = [0.09269e20, 0.20563e20]
	corrEff  = -0.897768

	# Define constants #
	deg2rad  = np.pi/180.
	fct      = 0.0276   ## Tau and Radiance
	fct_er   = 0.00072

	## Radiance to N(H)
	cf,cf_er = [4.05e31, 0.32e31]   ## From Radiance vs N(HI), 19 src without CO & OH and 16 src with low N(HI)
	of,of_er = [0.09e20, 0.21e20]

	nside    = hp.get_nside(rMap)
	res      = hp.nside2resol(512, arcmin=True)
	dd       = res/deg2rad/10.0

	d1       = fct_er/fct
	d2       = tauerMap/tauMap
	dr       = np.sqrt(d1**2 + d2**2)
	err      = rMap*dr
	err      = tauMap*fct*dr

	rMap     = 1e-4 * rMap  ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7
	rErMap   = 1e-4 * err  ## radiance W/m2/sr -> w/cm2/sr, xdata*1e11 => 1e7

	## Calculate the NH from Radiance #
	nhMap    = cf*rMap + of
	nhMap    = nhMap/1e20
	# NhErrMap = md.uncertainty_of_product(cf, rMap, cf_er, rErMap)
	NhErrMap = md.nh_uncert_from_proxies(rMap, rErMap, aa, aErr, bb, bErr, corrEff)
	NhErrMap = np.sqrt(NhErrMap**2 + of_er**2)
	NhErrMap = NhErrMap/1e20

	return nhMap, NhErrMap


## Cal NH-map from Tau-map #
 #
 # params array tauMap    Map of Tau353
 # params array tauerMap  Map of Tau353_error
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def getNhMapFomTauMap(tauMap, tauerMap):
	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown
	## find Planck Conversion Factor (Dust opacity and Its error) ## 
	planck_cf,pl_fact_err = [6.778e-27, 3.046e-28] #6.6e-27, 0.66e-26, lowNHI
	of,of_er              = [0., 0.]              ## If having intercerpt
	# planck_cf,pl_fact_err = [0.84e-26, 0.3e-26] #6.6e-27, 0.66e-26, lowNHI

	# planck_cf,pl_fact_err = [1.26e-26, 8.92e-28]   ## From tau353_vs_N(HI) fit (26 src without CO & 21 src with low N(HI))
	# of,of_er              = [-8.43e-27, 2.04e-27]

	nside  = hp.get_nside(tauMap)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# Calculate the N(HI) from Fukui factor #
	nhFKMap = fukui_cf*tauMap
	nhFKMap = nhFKMap/1e20	
   
	# Calculate the NH from Planck factor #
	nhMap   = tauMap/planck_cf
	nhMap   = nhMap/1e20

	# Uncertainties of mean values of N(HI) and N(H) #
	fukui_sd  = (tauerMap*fukui_cf)
	NhErrMap  = md.uncertainty_of_ratio(tauMap, planck_cf, tauerMap, pl_fact_err)
	NhErrMap  = np.sqrt(NhErrMap**2 + of_er**2)
	NhErrMap  = NhErrMap/1e20

	return nhMap, NhErrMap

## Get tau353 values and err_tau353 values #
 #
 # params str  mapFile File of maps
 # params str  SFDFile File of SFD98 E(B-V)
 #
 # return void
 #
 # version 08/2017 
 # Author Van Hiep ##	
def nh_from_tau(mapFile, SFDFile):
	# tau353 map, err_tau353 map and resolution #
	tauMap    = hp.read_map(mapFile, field=0)
	tauerMap  = hp.read_map(mapFile, field=1)
	rMap      = hp.read_map(mapFile, field=3)

	tauMap    = hp.ud_grade(tauMap, nside_out=512)
	tauerMap  = hp.ud_grade(tauerMap, nside_out=512)
	rMap      = hp.ud_grade(rMap, nside_out=512)
	rErMap    = 0.05*rMap

	SFD98Map  = hp.read_map(SFDFile, verbose=False, field=0)
	EbvMap    = 0.86*SFD98Map
	# AvMap     = EbvMap
	AvMap     = EbvMap*3.1
	AvErrMap  = 0.05*AvMap

	nhMap, \
	NhErrMap  = getNhMapFomTauMap(tauMap, tauerMap)
	nhMapR, \
	NhErrMapR = getNhMapFomRadianceMap(tauMap, tauerMap, rMap)

	# hp.mollview(tauMap, title=r'$\tau_{353}$', coord='G', unit='', norm='hist', sub=(1,1,1), notext=True) #, min=0.,max=452)
	# hp.mollview(tauerMap, title=r'$\tau_{353} Error$', coord='G', unit='', norm='hist', sub=(1,1,1), notext=True) #, min=0.,max=452)
	# hp.mollview(nhMap, title='$N_{H}[10^{20}cm^{-2}]$', coord='G', unit='', norm='hist', sub=(1,1,1), notext=True) #, min=0.,max=452)
	# hp.mollview(NhErrMap, title=r'$\sigma_{N_{H}}[10^{20}cm^{-2}]$', coord='G', unit='', norm='hist', sub=(1,1,1), notext=True) #, min=0.,max=452)
	# hp.mollview(EbvMap, title='$E(B-V)[mag]$', coord='G', unit='', norm='hist', sub=(1,1,1), notext=True) #, min=0.,max=452)
	# hp.graticule()
	# plt.grid()
	# plt.show()

	# print ''
	# ### Correlation: Radiance and NH ##
	# coxy  = md.cov_xy(ydat,xdat)
	# varx  = md.var(xdat)
	# vary  = md.var(ydat)
	# rho   = coxy/varx/vary
	
	# print ''
	# print '********* Pearson Coefficient *********'
	# print 'Pearson Coeff', md.pearson_coeff(xdat, ydat), ', ', rho
	# print ''


	### Radiance vs Av ###
	# NSIDE = 512	
	# mask  = np.zeros(hp.nside2npix(NSIDE), dtype=np.bool)
	# pixel_theta, pixel_phi = hp.pix2ang(NSIDE, np.arange(hp.nside2npix(NSIDE)))
	# mask[(pixel_theta > 4.*np.pi/9.) & (pixel_theta < 5.*np.pi/9.)] = 1

	# EbvMap = hp.ma(EbvMap)
	# EbvMap.mask = mask

	# rMap = hp.ma(rMap)
	# rMap.mask = mask

	# y   = EbvMap
	# x   = rMap*1e8

	x      = []
	xer    = []
	y      = []
	yer    = []
	step   = 0.1
	rMap   = rMap*1e8
	for xfiltr in np.arange(step, 300., step):
		filtr  = (AvMap<xfiltr) & (AvMap>(xfiltr-step))  ## filter
		xfiltr = AvMap[filtr]
		xerfil = AvErrMap[filtr]

		yfiltr = rMap[filtr]
		yerfil = rErMap[filtr]

		x.append(np.mean(xfiltr))
		xer.append(np.mean(xerfil))
		y.append(np.mean(yfiltr))
		yer.append(np.mean(yerfil))

	fig          = plt.figure(figsize=(20,10))
	ax           = fig.add_subplot(111); #ax.set_rasterized(True)                                 
	major_xticks = np.arange(0.0, 350., 20.)
	minor_xticks = np.arange(0.0, 350., 10.)
	major_yticks = np.arange(0.0, 80000., 5000.)
	minor_yticks = np.arange(0.0, 80000., 2500.)

	plt.errorbar(x, y, xerr=xer, yerr=yer, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.title('Radiance vs $A_{V}$', fontsize=30)
	plt.ylabel('$Radiance [10^{-8}Wm^{-2}sr^{-1}]$', fontsize=35)
	plt.xlabel('$A_{V} [mag]$', fontsize=35)
	plt.grid(False)
	
	ax.set_xticks(major_xticks)
	ax.set_xticks(minor_xticks, minor=True)
	ax.set_yticks(major_yticks)
	ax.set_yticks(minor_yticks, minor=True)
	plt.tick_params(axis='x', labelsize=22, pad=3)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=6)
	plt.tick_params(which='minor', length=3)

	plt.xlim(0., 350.)
	plt.ylim(0., 75000.)
	# plt.yscale('log')
	# plt.xscale('log')

	plt.tight_layout()
	# plt.legend(loc='upper left', fontsize=18)
	# plt.savefig('r_vs_av.eps', bbox_inches='tight' , format='eps', dpi=80)
	plt.show()

	sys.exit()

	### Plot all pixels ###
	# filtr  = AvMap<50.
	# xfiltr = AvMap[filtr]
	# xerfil = AvErrMap[filtr]

	# yfiltr = rMap[filtr]
	# yerfil = rErMap[filtr]

	# y      = yfiltr
	# yer    = yerfil

	# x      = xfiltr
	# xer    = xerfil

	# NSIDE = 512	
	# mask = np.zeros(hp.nside2npix(NSIDE), dtype=np.bool)
	# pixel_theta, pixel_phi = hp.pix2ang(NSIDE, np.arange(hp.nside2npix(NSIDE)))
	# mask[(pixel_theta > 4.*np.pi/9.) & (pixel_theta < 5.*np.pi/9.)] = 1

	# EbvMap = hp.ma(EbvMap)
	# EbvMap.mask = mask

	# rMap = hp.ma(rMap)
	# rMap.mask = mask

	# y   = EbvMap
	# x   = rMap*1e8

	# print len(EbvMap)

	### Correlation: Radiance and NH ##
	# coxy      = md.cov_xy(x,y)
	# varx      = md.var(x)
	# vary      = md.var(y)
	# rho       = coxy/varx/vary
	
	# print ''
	# print '********* Pearson Coefficient *********'
	# print 'Pearson Coeff', md.pearson_coeff(x, y), ', ', rho
	# print ''

	# plt.plot(np.array(x)/np.array(varx), np.array(y)/np.array(vary), 'r*')
	# plt.xlabel('X/varx')
	# plt.ylabel('Y/vary')
	# plt.show()
	### End - Correlation: Radiance and NH ##

	# fig = plt.figure(figsize=(14,12))
	# ax  = fig.add_subplot(111); #ax.set_rasterized(True) 

	# # plt.errorbar(x, y, xerr=xer, yerr=yer, color='r', marker='o', ls='None', markersize=3, markeredgecolor='b', markeredgewidth=1, label='data')
	# plt.plot(x, y, 'k.', label='data')
	# plt.title('Radiance vs Av', fontsize=30)
	# plt.ylabel('$Radiance [10^{-8}Wm^{-2}sr^{-1}]$', fontsize=35)
	# plt.xlabel('$A_{V} [mag]$', fontsize=35)
	# plt.grid(True)
	# # plt.xlim(0., 40.)
	# # plt.ylim(0., 0.3)
	# plt.tick_params(axis='x', labelsize=18)
	# plt.tick_params(axis='y', labelsize=15)
	# plt.show()

	# sys.exit()



	## NH vs Av ##
	# x      = []
	# xer    = []
	# y      = []
	# yer    = []
	# step   = 0.1
	# for xfiltr in np.arange(step, 25.01, step):
	# 	filtr  = (AvMap<xfiltr) & (AvMap>(xfiltr-step))  ## filter
	# 	xfiltr = AvMap[filtr]
	# 	xerfil = AvErrMap[filtr]
	# 	yfiltr = nhMap[filtr]
	# 	yerfil = NhErrMap[filtr]

	# 	yNhR   = nhMapR[filtr]
	# 	yErR   = NhErrMapR[filtr]

	# 	yfiltr = yfiltr/yNhR
	# 	yerfil = md.uncertainty_of_ratio(yfiltr, yNhR, yerfil, yErR)

	# 	x.append(np.mean(xfiltr))
	# 	xer.append(np.mean(xerfil))
	# 	y.append(np.mean(yfiltr))
	# 	yer.append(np.mean(yerfil))

	# # plt.errorbar(x, y, xerr=xer, yerr=yer, color='k', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	# plt.errorbar(x, y, xerr=xer, yerr=yer, color='k', label='data')
	# plt.title('N$_{H}$ (from Tau353) vs Av', fontsize=30)
	# plt.xlabel('Av', fontsize=35)
	# plt.ylabel('$N_{H} [10^{20}cm^{-2}]$', fontsize=35)
	# plt.grid(True)
	# # plt.ylim(-5e-7, 1e-6)
	# plt.tick_params(axis='x', labelsize=18)
	# plt.tick_params(axis='y', labelsize=15)
	# plt.show()


	## NH vs Av ##
	filtr  = AvMap<5.
	xfiltr = AvMap[filtr]
	xerfil = AvErrMap[filtr]

	yfiltr = nhMap[filtr]
	yerfil = NhErrMap[filtr]

	yNhR   = nhMapR[filtr]
	yErR   = NhErrMapR[filtr]

	yfiltr = yfiltr/yNhR
	yerfil = md.uncertainty_of_ratio(yfiltr, yNhR, yerfil, yErR)

	y      = yfiltr
	yer    = yerfil

	x      = xfiltr
	xer    = xerfil

	# plt.errorbar(x, y, xerr=xer, yerr=yer, color='k', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.errorbar(x, y, xerr=xer, yerr=yer, color='k', label='data')
	plt.title('N$_{H}$ (from Tau353) vs Av', fontsize=30)
	plt.xlabel('Av', fontsize=35)
	plt.ylabel('$N_{H} [10^{20}cm^{-2}]$', fontsize=35)
	plt.grid(True)
	# plt.ylim(-5e-7, 1e-6)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	plt.show()

##================= MAIN ========================##
## Filename of the map
pth     = os.getenv("HOME")+'/hdata/dust/'
mapFile = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from Planck r.12, IRAS ~5'
SFDFile = pth + 'lambda_sfd_ebv.fits'

## cal N(H)
nh_from_tau(mapFile, SFDFile)