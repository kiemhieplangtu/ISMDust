import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import matplotlib        as mpl
import numpy             as np
import healpy            as hp
import pylab             as pl
import module            as md
import operator

from   restore               import restore
from mpl_toolkits.axes_grid1 import make_axes_locatable


## Read infor of 94 src, atomic or molecular, CO? OH? #
 #
 # params string fname Filename
 # return dict info
 # 
 # version 09/2017
 # Author Van Hiep ##
def read_94src_atomic_info(fname = '../compare/94src_atomic_or_molecular.txt'):
	cols = ['src', 'l', 'b', 'atom', 'coyn', 'ohyn' ]
	fmt  = ['s',   'f', 'f',  'i',     'i',   'i'   ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read(asarray=True)
	return dat['src'], dat['l'], dat['b'], dat['atom'], dat['coyn'], dat['ohyn']

#================= MAIN ========================#	
xsc, \
xl, \
xb, \
atom, \
coyn, \
ohyn     = read_94src_atomic_info(fname = '../compare/94src_atomic_or_molecular.txt')

deg2rad  = np.pi/180.
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

info     = md.read_19src_noco_nooh(fname = '../../oh/result/19src_noCO_noOH.txt')
lownhi   = md.read_16src_lownhi(fname = '../../oh/result/16src_lowNHI.txt')
lowsrc   = lownhi['src']

dbeam    = 3.5/120.0 # Beam = 3.5' -> dbeam = beam/60/2

# TTYPE1  = 'TAU353  '           / Optical depth at 353GHz                        
# TTYPE2  = 'ERR_TAU '           / Error on optical depth                         
# TTYPE3  = 'EBV     '           / E(B-V) color excess                            
# TTYPE4  = 'RADIANCE'           / Integrated emission                            
# TTYPE5  = 'TEMP    '           / Dust equilibrium temperature                   
# TTYPE6  = 'ERR_TEMP'           / Error on T                                     
# TTYPE7  = 'BETA    '           / Dust emission spectral index                   
# TTYPE8  = 'ERR_BETA'           / error on Beta 

cbsize = '0.005%'
lbsize = 7
cbpad  = 2

## Radiance map ##
r_map  = hp.read_map(map_file, verbose=False, field = 0)
nside  = hp.get_nside(r_map)
res    = hp.nside2resol(nside, arcmin = False)
dd     = res/deg2rad/2.0

#====== For Plotting ======#
fig = plt.figure(1, figsize=(16,9))
hp.mollview(r_map, title='', coord='G', norm='log', sub=(1,1,1), cbar=True, xsize=800, min=2.2e-9, max=4.5e-3, format='%0.1e', unit=r'$\tau_{353}$')
hp.graticule(linestyle=':')

hp.projplot(0., 0., color='k', marker='x', markersize=8, lonlat=True, coord='G', markerfacecolor="None", markeredgecolor='k', markeredgewidth=2)

for i in range(len(xsc)):
	src   = xsc[i]
	l     = xl[i]
	b     = xb[i]

	theta = (90.0 - b)*deg2rad
	phi   = l*deg2rad
	pix   = hp.ang2pix(nside, theta, phi, nest=False)
	val   = r_map[pix]
	print src, l,b,pix, val

	if(atom[i]==1):
		if(src in lowsrc):
			hp.projplot(l, b, color='red', marker='*', markersize=10, markeredgecolor='red', lonlat=True, coord='G')
		else:
			hp.projplot(l, b, color='r', marker='o', markersize=8, markeredgecolor='r', lonlat=True, coord='G')		
	elif( (coyn[i]==1) or (ohyn[i]==1) ):
		if(src == '3C132'):
			hp.projplot(l, b, color='purple', marker='^', markersize=8, markeredgecolor='purple', lonlat=True, coord='G')
			hp.projtext(l+0.5, b-2.8, ''+src, lonlat=True, coord='G', fontsize=7, weight='bold', color='k')
		else:
			hp.projplot(l, b, color='b', marker='^', markersize=8, markeredgecolor='b', lonlat=True, coord='G')
	else:
		hp.projplot(l, b, color='k', marker='d', markersize=7, markeredgecolor='k', lonlat=True, coord='G')
	hp.projtext(l, b, ' '+src, lonlat=True, coord='G', fontsize=8, weight='bold', color='k')

# for i in range(0, len(lownhi['src'])):
# 	src   = lownhi['src'][i]
# 	l     = lownhi['l'][i]
# 	b     = lownhi['b'][i]

# 	theta = (90.0 - b)*deg2rad
# 	phi   = l*deg2rad
# 	pix   = hp.ang2pix(nside, theta, phi, nest=False)
# 	val   = r_map[pix]
# 	print src, l,b,pix, val
# 	hp.projplot(l, b, color='r', marker='^', markersize=10, lonlat=True, coord='G')

mpl.rcParams.update({'font.size':16})
fig.axes[1].texts[0].set_fontsize(32)

plt.savefig('src_locations.eps', format='eps', dpi=100)
# plt.savefig('src_locations.eps', bbox_inches='tight', pad_inches=0.01, format='eps', dpi=100)
plt.show()




sys.exit()
