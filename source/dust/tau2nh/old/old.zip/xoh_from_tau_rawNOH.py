import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md
import copy

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit
from scipy.odr           import *

## Linear fucntion ##
 #
 # params list/float p Parameters
 # params 
 #
 # return 
 #
 # version 03/2017 
 # author Nguyen Van Hiep ##
def lin_fc(p, x):
     m = p
     return m*x

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	# model  = p[0] * x + p[1]
	model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_noh(fname = '../../oh/result/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	ret  = {}
	for i in range(0,len(src)):
		# if dat['src'][i] not in ret.keys():
		ret[src[i]] = {}
		ret[src[i]]['noh']   = noh[i]
		ret[src[i]]['l']     = l[i]
		ret[src[i]]['b']     = b[i]
		ret[src[i]]['noher'] = er[i]

	return ret


## Cal NH from tau353 #
 #
 # params array tau_map  Map of tau353
 # params array err_map  Error map of tau353
 # params dict  info     Infor of the sources
 # params dict  noh      Infor of OH sources
 #
 # return list info
 # 
 # version 04/2017
 # Author Van Hiep ##
def nh_from_tau353(tau_map, err_map, info, noh):
	## Infor of sources
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	nhier = info['nhi_er']
	cnm   = info['cnm']
	cnmer = info['cnm_er']

	ohsc  = []
	for sc in noh:
		if(sc in src):
			ohsc.append(sc)

	# Define constants #
	deg2rad     = np.pi/180.
	fukui_cf    = 2.10e26
	fk_fact_err = 0.0 #unknown
	## find Planck Conversion Factor (Dust opacity and Its error) ## 
	planck_cf,pl_fact_err = [7.065e-27, 2.71e-28] #6.6e-27, 0.66e-26, lowNHI
	of,of_er              = [0., 0.]              ## If having intercerpt
	# planck_cf,pl_fact_err = [0.84e-26, 0.3e-26] #6.6e-27, 0.66e-26, lowNHI

	# planck_cf,pl_fact_err = [1.26e-26, 8.92e-28]   ## From tau353_vs_N(HI) fit (26 src without CO & 21 src with low N(HI))
	# of,of_er              = [-8.43e-27, 2.04e-27]

	# Define the width of area #
	beam   = 5.             # Beam = 5'
	dbeam  = beam/120.0     # Beam = 5' -> dbeam = beam/60/2 in degree
	offset = dbeam          # degree

	nside  = hp.get_nside(tau_map)
	res    = hp.nside2resol(nside, arcmin=False)
	dd     = res/deg2rad/10.0

	# OK - Go #
	rnhi    = []
	rnhi_er = []
	tau353  = []
	tau_er  = []
	nh      = []
	nher    = []
	nhfk    = []
	nhfker  = []
	roh     = []
	roh_er  = []
	rnh2    = []
	rnh2_er = []
	rsrc    = []
	rcnm    = []
	rcnm_er = []
	for i in range(len(src)):
		if (src[i] not in ohsc):
			continue

		# if( noh[src[i]]['noh'] > 4.):
		# 	continue

		l = info['l'][i]
		b = info['b'][i]

		# Cal. #
		theta = (90.0-b)*deg2rad
		phi   = l*deg2rad
		pix   = hp.ang2pix(nside, theta, phi, nest=False)

		if ( (err_map[pix] >= 6.9e-11) and (err_map[pix] <= 0.00081) and (tau_map[pix] > -1.0e30) ): # Checked Invalid error & Some pixels not defined
			tau_i   = tau_map[pix]
			t_err_i = err_map[pix]

		# Calculate the N(HI) from Fukui factor #
		nhfk_i = fukui_cf*tau_i	
	   
		# Calculate the NH from Planck factor #
		nh_i   = tau_i/planck_cf

		## N(H2) = (NH-NHI)/2 ##
		nh2    = (nh_i-nhi[i]*1e20)/2.

		## 3sources with NHI > NH
		if(nh2 < 0.):
			continue
		
		# print nh_i, nhi[i]*1e20, nh2
		nhfk.append(nhfk_i)
		nh.append(nh_i)

		# Uncertainties of mean values of N(HI) and N(H) #
		fukui_sd  = (t_err_i*fukui_cf)
		nh_er     = md.uncertainty_of_ratio(tau_i, planck_cf, t_err_i, pl_fact_err)
		nh_er     = np.sqrt(nh_er**2 + of_er**2)	

		nh2_er    = 0.5*md.uncertainty_of_diff(nh_er, nhier[i]*1e20)
		nher.append(nh_er)

		## N(H2) ##
		rnh2.append(nh2) ## e20
		rnh2_er.append(nh2_er) ## e20

		## N(OH) ##
		roh.append( noh[src[i]]['noh'] * 1e14) ## e14
		roh_er.append( noh[src[i]]['noher'] * 1e14) ## e14
		rsrc.append( src[i] )

		## N(HI) ##
		rnhi.append(nhi[i]*1e20)
		rnhi_er.append(nhier[i]*1e20)

		## CNM ##
		rcnm.append(cnm[i]*1e20)
		rcnm_er.append(cnmer[i]*1e20)

		# print src[i], nh_i, planck_sd, nhi[i], nhier[i], nh2, nh2_er, noh[src[i]]['noh'], noh[src[i]]['noher']

	return rnh2, rnh2_er, roh, roh_er, rsrc, nh, nher, rnhi, rnhi_er, rcnm, rcnm_er

## Get tau353 values and err_tau353 values #
 #
 # params str map_file File of maps
 # params dict info   Information of sources
 # params dict lownhi Information of 21 OH sources
 #
 # return void
 #
 # version 11/2016 
 # Author Van Hiep
 ##	
def noh_vs_nh2(map_file, info, noh):
	## 26 sources without CO
	src   = info['src']  ## 26 src without CO
	nhi   = info['nhi']
	# oh    = info['oh']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	# tau353 map, err_tau353 map and resolution #
	tau_map  = hp.read_map(map_file, field = 0)
	err_map  = hp.read_map(map_file, field = 1)

	nh2, nh2_er, roh, roh_er, rsrc, \
	nh, nher, rnhi, rnhi_er, rcnm, rcnm_er = nh_from_tau353(tau_map, err_map, info, noh)

	## To Plot ##
	xdata  = roh
	ydata  = nh2

	# Error bar for x-axis and y-axis
	xerr   = roh_er
	yerr   = nh2_er

	########### MPFIT ############
	xdata  = np.array(xdata)
	ydata  = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr   = np.array(xerr)
	yerr   = np.array(yerr)

	## Histogram ##
	xoh    = xdata/ydata
	xoh_er = md.uncertainty_of_ratio(xdata, ydata, xerr, yerr)
	print 'Mean: ', xoh.mean()
	for x in xoh:
		print 1, x*1e8  ## xoh_from_tau.txt

##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'

# Info of 26 sources with no CO - l/b/name && 23 src low NHI #
# lownhi   = md.read_23rc_lownhi(fname = '../../oh/result/23src_lowNHI.txt')
info     = md.read_nhi_93src(fname = '../../hi/result/nhi_thin_cnm_wnm_94src_scaled.txt')
noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
noh      = read_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')
noh      = read_noh(fname = '../../oh/NOH/total_raw_noh67_21src.txt')

print noh

## cal N(H2)
noh_vs_nh2(map_file, info, noh)