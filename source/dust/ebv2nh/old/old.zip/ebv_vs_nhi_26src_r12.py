import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import healpy            as hp
import module            as md

from restore             import restore

## Get ebv values and err_ebv values from 26 sources without CO#
 # Than calculate N(H) from Dust
 #
 # params str map_file File of maps
 # params dict info Information of 26 no CO sources
 # params dict lownhi Information of 23 Low NHI sources
 #
 # return void
 # 
 # version 12/2016
 # Author Van Hiep ##	
def cal_nh_from_dust(map_file, info, lownhi):
	## 19 sources without CO & OH
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	thinr = info['thin_er']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	## 16 lownhi sources
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']

	# TFORM1  = 'EBV       '          /data format of field: 4-byte REAL
	# TTYPE2  = 'N_OBS   '           /label for field   2
	tau_map    = hp.read_map(map_file, field = 0)
	tauer_map  = hp.read_map(map_file, field = 1)
	ci_map     = hp.read_map(map_file, field = 2)
	ci, cier   = md.cal_ebv_from_planckR12(tau_map, tauer_map, ci_map, info)
	xci, xcier = md.cal_ebv_from_planckR12(tau_map, tauer_map, ci_map, lownhi)

	y   = nhi + hi
	x   = ci  + xci

	yer = nhier + hier
	xer = cier  + xcier

	########### MPFIT ############
	xdata = np.array(x)
	ydata = np.array(y)

	# Error bar for x-axis and y-axis
	xerr = np.array(xer)
	yerr = np.array(yer)

	print ''
	### Correlation: Radiance and NH ##
	coxy      = md.cov_xy(ydata,xdata)
	varx      = md.var(xdata)
	vary      = md.var(ydata)
	rho       = coxy/varx/vary
	
	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdata, ydata), ', ', rho
	print ''

	plt.plot(np.array(xdata)/np.array(varx), np.array(ydata)/np.array(vary), 'r*')
	plt.xlabel('X/varx')
	plt.ylabel('Y/vary')
	plt.show()
	### End - Correlation: Radiance and NH ##

	########### ODR fit ############
	## Fit ##	
	xfit, yfit, mu, sig, m, ea, b, eb = md.do_linODRfit(xdata, ydata, xerr, yerr, lguess=[58., 5.])

	# plt.plot(xdata,ydata, 'ok', ls='None', marker='.', lw=1, label='Factor $f = N_{HI}$/$N^*_{HI}$')
	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.xlabel('$E(B-V) [mag]$', fontsize=35)
	plt.ylabel('$N_{HI} [10^{20} cm^{-2}]$', fontsize=35)
	# plt.xlim(0.0, 2.0)
	plt.ylim(0.8, 35.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='y', style='sci', scilimits=(0,0))

	plt.text(0.01, 18., '$f = ['+str(m)+'\pm'+str(ea) +']\cdot10^{20} E(B-V) + ['+str(b)+'\pm'+str(eb)+']\cdot10^{20}$', color='blue', fontsize=20)
	# plt.text(0.01, 18., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{20} E(B-V)$', color='blue', fontsize=20)
	plt.text(0.01, 13., r'$N_{H} = 58\cdot10^{20}\cdot E(B-V)\ [cm^{-2}mag^{-1}]$', color='k', fontsize=17)
	plt.gca().set_xscale('log', basex=10)
	plt.gca().set_yscale('log', basex=10)
	plt.legend(loc='upper left', fontsize=18)
	# for i in range(len(src)):
	# 	if(oh[i] > 0):
	# 		plt.annotate('('+str(src[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	# 	            xytext=(-50.,30.), textcoords='offset points',
	# 	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	# 	            )
	plt.show()
	########### END - ODR ############

#================= MAIN ========================#
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from Planck, ~5'

# Info of 19 sources with noCO, noOH and 23 src low NHI- l/b/name && #
info   = md.read_19src_noco_nooh(fname = '../../oh/result/19src_noCO_noOH.txt')
lownhi = md.read_16rc_lownhi(fname = '../../oh/result/16src_lowNHI.txt')

cal_nh_from_dust(map_file, info, lownhi)
# plot_patches(map_file, info)