import sys, os
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import matplotlib        as mpl
import numpy             as np
import healpy            as hp
import module            as md

from   restore           import restore

## Read info of 23 LOW NHI sources #
 # l,b, nhi, and nhi_error
 #
 # params string fname Filename
 # return dict info
 # 
 # version 12/2016
 # Author Van Hiep ##
def read_ebv_lownhi_noco(fname = 'data/ebv_sfd98_sf2011.txt', sfd98=False):
	cols = ['idx','src','l', 'b', 'ci','ci_er','ebv','ebv_er', 'ebvsf','ebvsf_er']
	fmt  = ['i',  's',  'f', 'f', 'f',   'f',   'f',  'f'    , 'f',   'f'    ]
	data = restore(fname, 2, cols, fmt)
	dat  = data.read()

	if(sfd98):
		return dat['ebv'], dat['ebv_er']
	else:
		return dat['ebvsf'], dat['ebvsf_er']

## Get ebv values and err_ebv values from 26 sources without CO#
 # Than calculate N(H) from Dust
 #
 # params str map_file File of maps
 # params dict info Information of 26 no CO sources
 # params dict lownhi Information of 23 Low NHI sources
 #
 # return void
 # 
 # version 12/2016
 # Author Van Hiep ##	
def cal_nh_from_dust(map_file, info, lownhi):
	## 19 sources without CO & OH
	src   = info['src']
	nhi   = info['nhi']
	thin  = info['thin']
	thinr = info['thin_er']
	nhier = info['nhi_er']
	xl    = info['l']
	xb    = info['b']

	## 16 lownhi sources
	lsc    = lownhi['src']
	hi     = lownhi['nhi']
	hier   = lownhi['nhi_er']
	lthin  = lownhi['thin']
	lthinr = lownhi['thin_er']

	## in the order of 26src_no_CO then 23 src low N(HI)
	ebv, ebv_er = read_ebv_lownhi_noco(fname = 'data/ebv_sfd98_sf2011.txt')
	x           = ebv
	xer         = ebv_er
	y           = nhi   + hi
	yer         = nhier + hier
	los         = src   + lsc

	########### FIT ############
	xdata = np.array(x)
	ydata = np.array(y)

	# Error bar for x-axis and y-axis
	xerr = np.array(xer)
	yerr = np.array(yer)

	print xdata.shape
	print ydata.shape

	for i in range(len(xdata)):
		print xdata[i], xerr[i], ydata[i], yerr[i]

	print ''
	### Correlation: Radiance and NH ##
	coxy      = md.cov_xy(ydata,xdata)
	varx      = md.var(xdata)
	vary      = md.var(ydata)
	rho       = coxy/varx/vary
	
	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdata, ydata), ', ', rho
	print ''

	plt.plot(np.array(xdata)/np.array(varx), np.array(ydata)/np.array(vary), 'r*')
	plt.xlabel('X/varx')
	plt.ylabel('Y/vary')
	plt.show()
	### End - Correlation: Radiance and NH ##

	## Fit ODR for data from Schlafly 2011 ##	
	xfit, yfit, mu, sig, m, ea, b, eb = md.do_linODRfit(xdata, ydata, xerr, yerr, lguess=[58., 5.])

	### E(B-V) from Planck R1.2 ###
	# TFORM1  = 'EBV       '          /data format of field: 4-byte REAL
	# TTYPE2  = 'N_OBS   '           /label for field   2
	tau_map    = hp.read_map(map_file, field = 0)
	tauer_map  = hp.read_map(map_file, field = 1)
	ci_map     = hp.read_map(map_file, field = 2)
	ci, cier   = md.cal_ebv_from_planckR12(tau_map, tauer_map, ci_map, info)
	xci, xcier = md.cal_ebv_from_planckR12(tau_map, tauer_map, ci_map, lownhi)

	yy         = nhi   + hi
	xx         = ci    + xci

	yyer       = nhier + hier
	xxer       = cier  + xcier

	########### FIT ############
	xdat       = np.array(xx)
	ydat       = np.array(yy)

	# Error bar for x-axis and y-axis
	xer        = np.array(xxer)
	yer        = np.array(yyer)

	print ''
	### Correlation: Radiance and NH ##
	coxy       = md.cov_xy(ydat,xdat)
	varx       = md.var(xdat)
	vary       = md.var(ydat)
	rho        = coxy/varx/vary
	
	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdat, ydat), ', ', rho
	print ''

	plt.plot(np.array(xdat)/np.array(varx), np.array(ydat)/np.array(vary), 'r*')
	plt.xlabel('X/varx')
	plt.ylabel('Y/vary')
	plt.show()

	## Fit ODR for data from Placnk 2014 R1.2 ##	
	xFit, yFit, Mu, Sig, M, Ea, B, Eb = md.do_linODRfit(xdat, ydat, xer, yer, lguess=[58., 5.])

	### End - Correlation: Radiance and NH ###
	### END - E(B-V) from Planck R1.2      ###


	### PLOT FIGURES ###
	mpl.rcParams['axes.linewidth'] = 2.
	f,(ax1, ax2) = plt.subplots(2, 1, gridspec_kw = {'wspace':0, 'hspace':0.02}, figsize=(10,8))

	major_xticks = np.arange(0., 0.5, 0.1)
	minor_xticks = np.arange(0., 0.5, 0.05)
	major_yticks = np.arange(0., 80., 10.)                                              
	minor_yticks = np.arange(0., 80., 5.0)

	ax1.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='k', marker='o', ls='None', markersize=6, markeredgecolor='k', markeredgewidth=1, label='data')
	ax1.plot(xfit, mu, '-k', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='k', markersize=0, label='ODR linear fit')
	ax1.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)
	xerb1, = ax1.plot(xdata, ydata, color='k', marker='o', ls='None', markersize=5, markeredgecolor='k', markeredgewidth=1, label='') 

	ax1.set_ylabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=20)
	
	ax1.set_xticks(major_xticks)                                                       
	ax1.set_xticks(minor_xticks, minor=True)                                           
	ax1.set_yticks(major_yticks)                                                       
	ax1.set_yticks(minor_yticks, minor=True)
	ax1.tick_params(axis='x', pad=0, labelbottom='off')
	ax1.tick_params(axis='y', labelsize=16)
	ax1.tick_params(which='both', width=1.5)
	ax1.tick_params(which='major', length=9)
	ax1.tick_params(which='minor', length=4)

	ax1.set_xlim(0.008, 0.5)
	ax1.set_ylim(0.8, 40.)

	ax1.set_xscale('log')
	ax1.set_yscale('log')

	ax1.set_xticks([0.01, 0.05, 0.1, 0.3])
	ax1.set_yticks([1, 5, 10, 30])
	ax1.get_xaxis().set_major_formatter(mpl.ticker.FormatStrFormatter('%.2f'))
	ax1.get_yaxis().set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))

	axbox = ax1.get_position()
	leg   = ax1.legend([xerb1], [r'$\mathrm{E(B-V)\ from\ Schlafly\ et\ al. (2011)}$'], \
		 fontsize=13, loc=(axbox.x0-0.1, axbox.y0+0.3), numpoints=1)
	leg.get_frame().set_linewidth(0.0)

	
	### Ax2 ###
	ax2.errorbar(xdat, ydat, xerr=xer, yerr=yer, color='k', marker='h', ls='None', markersize=6, markeredgecolor='k', markeredgewidth=1, label='data')
	ax2.plot(xFit, Mu, '-k', mew=2, linewidth=2, linestyle='solid', marker='h', markerfacecolor='k', markersize=0, label='ODR linear fit')
	ax2.fill_between(xFit, Mu-Sig, Mu+Sig, color='0.5', alpha=0.5)
	xerb1, = ax2.plot(xdat, ydat, color='k', marker='h', ls='None', markersize=5, markeredgecolor='k', markeredgewidth=1, label='') 

	# plt.title('', fontsize=30)
	plt.xlabel(r'$\mathrm{E(B-V) [mag]}$', fontsize=20)
	plt.ylabel(r'$\mathrm{N_{H} [10^{20} cm^{-2}]}$', fontsize=20)

	ax2.set_xticks(major_xticks)                                                       
	ax2.set_xticks(minor_xticks, minor=True)                                           
	ax2.set_yticks(major_yticks)                                                       
	ax2.set_yticks(minor_yticks, minor=True)
	ax2.tick_params(axis='x', labelsize=16, pad=5)
	ax2.tick_params(axis='y', labelsize=16)
	ax2.tick_params(which='both', width=1.5)
	ax2.tick_params(which='major', length=9)
	ax2.tick_params(which='minor', length=4)

	ax2.set_xlim(0.008, 0.5)
	ax2.set_ylim(0.8, 40.)

	ax2.set_xscale('log')
	ax2.set_yscale('log')

	ax2.set_xticks([0.01, 0.05, 0.1, 0.3])
	ax2.set_yticks([1, 5, 10, 30])
	ax2.get_xaxis().set_major_formatter(mpl.ticker.FormatStrFormatter('%.2f'))
	ax2.get_yaxis().set_major_formatter(mpl.ticker.FormatStrFormatter('%.0f'))

	axbox = ax2.get_position()
	leg   = ax2.legend([xerb1], [r'$\mathrm{E(B-V)\ from\ PLC2014a}$'], \
		 fontsize=13, loc=(axbox.x0-0.1, axbox.y0+0.7), numpoints=1)
	leg.get_frame().set_linewidth(0.0)

	plt.savefig('ebv_vs_nh.eps', bbox_inches='tight', pad_inches=0.03, format='eps', dpi=600)
	plt.show()
	########### END - ODR ############

	for i in range(len(los)):
		nh = m*xdata[i]+b
		print i, los[i],'     \t', xdata[i],'\t', ydata[i],'\t', nh,'\t', nh-ydata[i]  ## compare/nh_from_ebv2011.txt

#================= MAIN ========================#
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'HFI_CompMap_ThermalDustModel_2048_R1.20.fits'  ## E(B-V) from SFD et al. 1998, IRAS ~6'

# Info of 19 sources with noCO, noOH and 23 src low NHI- l/b/name && #
info   = md.read_19src_noco_nooh(fname = '../../oh/result/19src_noCO_noOH.txt')
lownhi = md.read_23rc_lownhi(fname = '../../oh/result/16src_lowNHI.txt')

cal_nh_from_dust(map_file, info, lownhi)