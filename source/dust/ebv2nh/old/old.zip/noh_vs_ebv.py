import os, sys
sys.path.insert(0, os.getenv("HOME")+'/dark/common') # add folder of Class

import matplotlib.pyplot as plt
import numpy             as np
import matplotlib        as mpl
import healpy            as hp
import pylab             as pl
import module            as md
import copy

from numpy               import array
from restore             import restore
from plotting            import cplot
from mpfit               import mpfit
from scipy.odr           import *

## Linear fucntion ##
 #
 # params list/float p Parameters
 # params 
 #
 # return 
 #
 # version 03/2017 
 # author Nguyen Van Hiep ##
def lin_fc(p, x):
     m = p
     return m*x

## Linear ##
 #
 # params 
 # params 
 #
 # return 
 #
 # version 08/2016 
 # author Nguyen Van Hiep ##
# def tb_exp(x,y,bg,tau,v0,wid,tex,cont,err=1.):
def myfunc(p, fjac=None, x=None, y=None, err=None):
	# model  = p[0] * x + p[1]
	model  = p[0] * x
	status = 0
	return [status, (y - model) / err]

## Read info of OH sources #
 # l,b, noh, noh_er
 #
 # params string fname Filename
 # return dict info
 # 
 # version 4/2017
 # Author Van Hiep ##
def read_total_noh(fname = '../../oh/OH/total_noh65_21src.txt'):
	cols = ['idx','src','l', 'b', 'noh', 'noh_er']
	fmt  = ['i', 's',   'f', 'f', 'f',   'f']
	data = restore(fname, 2, cols, fmt)
	dat  = data.read(asarray=True)
	noh  = dat['noh']
	er   = dat['noh_er']
	src  = dat['src']
	l    = dat['l']
	b    = dat['b']

	# ret  = {}
	# for i in range(0,len(src)):
	# 	# if dat['src'][i] not in ret.keys():
	# 	ret[src[i]] = {}
	# 	ret[src[i]]['noh']   = noh[i]
	# 	ret[src[i]]['l']     = l[i]
	# 	ret[src[i]]['b']     = b[i]
	# 	ret[src[i]]['noher'] = er[i]

	return noh, er, l, b

## Plot N(OH) vs E(B-V) #
 #
 # params 
 # params 
 #
 # return void
 #
 # version 07/2017 
 # Author Van Hiep
 ##	
def noh_vs_ebv():
	noh, noher,\
	xl, xb           = read_total_noh(fname = '../../oh/NOH/total_noh67_21src.txt')
	# noh, noher       = read_total_noh(fname = '../../oh/NOH/total_noh67_21src_carl.txt')
	# noh, noher       = read_total_noh(fname = '../../oh/NOH/total_raw_noh67_21src.txt')
	ebv, ebver, \
	Av, ohsc         = md.read_ebv_for_oh_src(fname = 'data/ebv_sfd98_sf2011_for_oh_src.txt', sfd98=False)
	Aver             = 3.1*np.array(ebver)

	ratErr           = md.uncertainty_of_ratio(noh, Av, noher, Aver)

	print ratErr[2]

	for i in range(len(ebv)):
		# print i, ohsc[i], ebv[i], ebver[i], Av[i], Aver[i], noh[i]/Av[i]
		string = '{:10s} {:14s}   {:14s} {:14s}'\
		.format(ohsc[i]+' &', str(round(noh[i],2))+'$\pm$'+str(round(noher[i],2))+' &', str(round(Av[i],2))+'$\pm$'+str(round(Aver[i],2))+' &', str(round(noh[i]/Av[i],2))+'$\pm$'+str(round(ratErr[i],2))+' \\\\' )
		print string



	## From Crutcher 1979 - 1979ApJ...234..881C/0000888.000.html ##
	# Av   = np.array([1.0, 1.0, 1.0, 2.0, 2.0, 0.4, 2.0, 2.8, 2.2, 4.4 ])
	# Aver = Av*0.05
	# noh  = np.array([9.7, 5.2, 5.1, 21., 15., 3., 25., 20., 80., 80. ])/10.
	# noher = noh*0.05
	## End - From Crutcher 1979 ##

	## To Plot ##
	xdata = Av
	ydata = noh

	# Error bar for x-axis and y-axis
	xerr  = Aver
	yerr  = noher

	########### MPFIT ############
	xdata = np.array(xdata)
	ydata = np.array(ydata)

	# Error bar for x-axis and y-axis
	xerr  = np.array(xerr)
	yerr  = np.array(yerr)

	print ''
	print '********* Pearson Coefficient *********'
	print 'Pearson Coeff', md.pearson_coeff(xdata, ydata)

	## Fit ##
	lguess  = [1.0]
	# lguess  = [58.0]

	npar    = len(lguess)
	guessp  = np.array(lguess, dtype='float64')
	plimd   = [[False,False]]*npar
	plims   = [[0.,0.]]*npar
	parbase = {'value': 0., 'fixed': 0, 'parname': '', 'limited': [0, 0], 'limits': [0., 0.]}
	pname   = ['slope','offset']
	pfix    = [False]*npar

	parinfo = []
	for i in range(len(guessp)):
		parinfo.append(copy.deepcopy(parbase))

	for i in range(len(guessp)):
		parinfo[i]['value']   = guessp[i]
		parinfo[i]['fixed']   = pfix[i]
		parinfo[i]['parname'] = pname[i]
		parinfo[i]['limited'] = plimd[i]

	x  = xdata.astype(np.float64)
	y  = ydata.astype(np.float64)
	er = yerr.astype(np.float64)

	########### ODR fit ############
	# Create a model for Orthogonal distance regression (ODR) fitting.
	lin_model = Model(lin_fc)
	# Create a RealData object using our initiated data from above.
	data      = RealData(xdata, ydata, sx=xerr, sy=yerr)
	# Set up ODR with the model and data.
	odr       = ODR(data, lin_model, beta0=lguess)
	# Run the regression.
	out       = odr.run()

	## ********* Results ********* ##
	print '********* ODR Results *********'
	abp   = out.beta
	abper = out.sd_beta
	for i in range(len(lguess)):
		print "%s = %03.8f +/- %03.8f" % (parinfo[i]['parname'],abp[i],abper[i])
	## Plot ##
	a     = np.array([ abp[0]-abper[0], abp[0]+abper[0] ])
	# b     = np.array([ abp[1]-abper[1], abp[1]+abper[1] ])
	xfit  = np.linspace(xdata.min(), xdata.max(), 20)
	# yfit  = a[:, None] * xfit + b[:, None]
	yfit  = a[:, None] * xfit
	mu    = yfit.mean(0)
	sig   = 1.0*yfit.std(0)
	# fit   = abp[0]*x+abp[1]
	fit   = abp[0]*x

	m  = round(abp[0],2)
	# b  = round(abp[1],2)
	ea = round(abper[0],2)
	# eb = round(abper[1],2)

	# plt.plot(xdata,ydata, 'ok', ls='None', marker='.', lw=1, label='Factor $f = N_{HI}$/$N^*_{HI}$')
	plt.errorbar(xdata, ydata, xerr=xerr, yerr=yerr, color='r', marker='o', ls='None', markersize=8, markeredgecolor='b', markeredgewidth=1, label='data')
	plt.plot(xfit, mu, '-b', mew=2, linewidth=2, linestyle='solid', marker='o', markerfacecolor='b', markersize=0, label='ODR linear fit')
	plt.fill_between(xfit, mu - sig, mu + sig, color='0.5', alpha=0.5)

	plt.title('N$_{OH}$ (from Hiep) vs A$_{V}$', fontsize=30)
	plt.xlabel('$A_{V}$ mag', fontsize=35)
	plt.ylabel('$N_{OH} [10^{14} (cm^{-2}$]', fontsize=35)
	# plt.xlim(0.2, 10.0)
	# plt.ylim(-1.0, 6.0)
	plt.grid(True)
	plt.tick_params(axis='x', labelsize=18)
	plt.tick_params(axis='y', labelsize=15)
	# plt.ticklabel_format(axis='x', style='sci', scilimits=(0,0))
	# plt.yscale('log')
	# plt.xscale('log')

	# plt.text(0.21, 12., '$N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R + ['+str(b)+'\pm'+str(eb)+']\cdot10^{20}$', color='blue', fontsize=20)
	# plt.text(0.21, 10, '(Data points with no CO and OH detected)', color='k', fontsize=20)
	# plt.text(0.001, 12., '$Fit: N_{H} = ['+str(m)+'\pm'+str(ea) +']\cdot10^{31} R$', color='blue', fontsize=20)
	# plt.gca().set_xscale('log', basex=10)
	# plt.gca().set_yscale('log', basex=10)
	plt.legend(loc='upper left', fontsize=18)
	for i in range(len(ohsc)):
		# if(oh[i] > 0):
		# plt.annotate('('+str(ohsc[i])+', '+ str(xl[i])+', '+str(xb[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
		plt.annotate('('+str(ohsc[i])+')', xy=(xdata[i], ydata[i]), xycoords='data',
	            xytext=(-50.,30.), textcoords='offset points',
	            arrowprops=dict(arrowstyle="->"),fontsize=12,
	            )
	plt.show()
	########### END - ODR ############

	## Histogram ##
	r    = ydata/xdata
	print 'Mean: ', r.mean()
	xmin = 10.*r.min()
	xmax = 10.*r.max()
	plt.hist(10.*r, alpha=0.5, label='', color='b', ls='-',  histtype='stepfilled', stacked=False, fill=True, range=(xmin,xmax), bins=10, lw=2)

	plt.title('N$_{OH}$/A$_{V}$ (from Hiep)', fontsize=22)
	plt.ylabel('Number of sightlines', fontsize=22,fontweight='bold')
	plt.xlabel('$N_{OH}/A_{V}$ [$10^{13}cm^{-2}mag^{-1}$]', fontsize=22, fontweight='bold')

	plt.tick_params(axis='x', labelsize=22, pad=8)
	plt.tick_params(axis='y', labelsize=22)
	plt.tick_params(which='both', width=2)
	plt.tick_params(which='major', length=9)
	plt.tick_params(which='minor', length=4)
	# plt.legend(loc='upper right', fontsize=22)
	plt.grid(False)
	plt.ylim(0., 8.)

	# plt.text(0.05, 15.0, 'Far from 1.0 are l-o-s with very low N(HI) (<3.0e20)', color='blue', fontsize=20)

	plt.tight_layout()
	plt.show()


##================= MAIN ========================##
## Filename of the map
pth      = os.getenv("HOME")+'/hdata/dust/'
map_file = pth + 'lambda_sfd_ebv.fits'  ## E(B-V) from SFD et al. 1998, IRAS ~6'

## cal N(H2)
noh_vs_ebv()